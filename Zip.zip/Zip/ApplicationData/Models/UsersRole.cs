﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class UsersRole
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public DateTime LastUpdate { get; set; }
        public int Id { get; set; }

        public virtual Users User { get; set; }
    }
}
