﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Feature
    {
        public Feature()
        {
            FeaturePermission = new HashSet<FeaturePermission>();
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public TimeSpan? LastUpdate { get; set; }

        public virtual ICollection<FeaturePermission> FeaturePermission { get; set; }
    }
}
