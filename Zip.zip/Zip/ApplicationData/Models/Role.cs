﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace ApplicationData.Models
{
    public partial class Role
    {
        public Role()
        {
            RoleFeaturePermission = new HashSet<RoleFeaturePermission>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public BitArray Enabled { get; set; }
        public DateTime LastUpdate { get; set; }

        public virtual ICollection<RoleFeaturePermission> RoleFeaturePermission { get; set; }
    }
}
