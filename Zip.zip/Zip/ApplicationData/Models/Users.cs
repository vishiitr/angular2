﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Users
    {
        public Users()
        {
            UsersRole = new HashSet<UsersRole>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string LoginId { get; set; }
        public string Password { get; set; }
        public DateTime LastUpdate { get; set; }
        public string EmailId { get; set; }

        public virtual ICollection<UsersRole> UsersRole { get; set; }
    }
}
