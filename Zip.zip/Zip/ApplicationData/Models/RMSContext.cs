﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApplicationData.Models
{
    public partial class RMSContext : DbContext
    {
        public virtual DbSet<Feature> Feature { get; set; }
        public virtual DbSet<FeaturePermission> FeaturePermission { get; set; }
        public virtual DbSet<PermissionType> PermissionType { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RoleFeaturePermission> RoleFeaturePermission { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<UsersRole> UsersRole { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
            optionsBuilder.UseNpgsql(@"Host=localhost;Database=RMS;Username=postgres;Password=Password");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Feature>(entity =>
            {
                entity.ToTable("feature");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_bookmark_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasColumnName("title")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<FeaturePermission>(entity =>
            {
                entity.ToTable("feature_permission");

                entity.HasIndex(e => new { e.FeatureId, e.PermissionId })
                    .HasName("UNQ_feature_permisslon")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_bookmark_permission_id'::regclass)");

                entity.Property(e => e.FeatureId).HasColumnName("feature_id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.PermissionId).HasColumnName("permission_id");

                entity.HasOne(d => d.Feature)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.FeatureId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK1_feature_permission");

                entity.HasOne(d => d.Permission)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.PermissionId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK2_feature_permission");
            });

            modelBuilder.Entity<PermissionType>(entity =>
            {
                entity.ToTable("permission_type");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_permission_type_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Enabled)
                    .IsRequired()
                    .HasColumnName("enabled")
                    .HasColumnType("bit")
                    .HasDefaultValueSql("B'1'::\"bit\"");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("role");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_role_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Enabled)
                    .IsRequired()
                    .HasColumnName("enabled")
                    .HasColumnType("bit");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<RoleFeaturePermission>(entity =>
            {
                entity.ToTable("role_feature_permission");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.FeaturePermissionId).HasColumnName("feature_permission_id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.RoleId)
                    .HasColumnName("role_id")
                    .HasDefaultValueSql("nextval('seq_role_bookmark_permission_id'::regclass)");

                entity.HasOne(d => d.FeaturePermission)
                    .WithMany(p => p.RoleFeaturePermission)
                    .HasForeignKey(d => d.FeaturePermissionId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK2_role_feature_permission");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleFeaturePermission)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK1_role_feature_permission");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("users");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_user_id'::regclass)");

                entity.Property(e => e.EmailId)
                    .IsRequired()
                    .HasColumnName("email_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.LoginId)
                    .IsRequired()
                    .HasColumnName("login_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UsersRole>(entity =>
            {
                entity.ToTable("users_role");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UsersRole)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_users_role");
            });

            modelBuilder.HasSequence("seq_bookmark_id").HasMin(0);

            modelBuilder.HasSequence("seq_bookmark_permission_id");

            modelBuilder.HasSequence("seq_permission_type_id");

            modelBuilder.HasSequence("seq_role_bookmark_permission_id");

            modelBuilder.HasSequence("seq_role_id");

            modelBuilder.HasSequence("seq_user_id");
        }
    }
}