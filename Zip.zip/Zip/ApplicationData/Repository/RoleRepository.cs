﻿using ApplicationData.Models;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace ApplicationData
{
    /// <summary>
    /// Represents the Application Version Repository
    /// </summary>
    public class RoleRepository : RepositoryBase<Role>, IRoleRepository
    {
        public RoleRepository()
        {
        }

        public Role GetRole(int id)
        {
            return GetAll().Where(t => t.Id == id).Include("RoleFeaturePermission").Include("RoleFeaturePermission.FeaturePermission")
                .Include("RoleFeaturePermission.FeaturePermission.Feature").Include("RoleFeaturePermission.FeaturePermission.Permission").First();
        }

        public bool UpdateRoleFeaturePermission(string listOfPermissionId, int roleId)
        {
            var csvFeaturesPermissions = new Npgsql.NpgsqlParameter("features_permissions", NpgsqlTypes.NpgsqlDbType.Text);
            csvFeaturesPermissions.Value = listOfPermissionId;
            var crntRoleId = new Npgsql.NpgsqlParameter("crnt_role_id", NpgsqlTypes.NpgsqlDbType.Integer);
            crntRoleId.Value = roleId;

            var result = this.dbContext.Database.ExecuteSqlCommand("select update_role_features_permissions(@features_permissions, @crnt_role_id)", new[] { csvFeaturesPermissions, crntRoleId });

            return result == 0 ? true : false;
        }
    }
}
