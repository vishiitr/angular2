﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace ApplicationData
{
    /// <summary>
    /// Defines the contract for implementing IRepository
    /// </summary>
    public interface IRepository
    {

    }

    /// <summary>
    /// Defines the contract for implementing IRepository
    /// </summary>
    /// <typeparam name="TEntity">The type of the t entity.</typeparam>
    public interface IRepository<TEntity>
    {
        /// <summary>
        /// Insert a new entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>TEntity.</returns>
        TEntity Insert(TEntity entity);

        /// <summary>
        /// Updates the existing entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>TEntity.</returns>
        TEntity Update(TEntity entity);

        /// <summary>
        /// Delete the given entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        void Delete(TEntity entity);

        /// <summary>
        /// Finds one entity based on its Identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>TEntity.</returns>
        TEntity Get(object id);

        /// <summary>
        /// Finds entities based on provided criteria.
        /// </summary>
        /// <param name="where">The where.</param>
        /// <returns>IQueryable&lt;TEntity&gt;.</returns>
        IQueryable<TEntity> GetAll(Expression<Func<TEntity, bool>> where = null);

        /// <summary>
        /// Save any changes to the TContext
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool SaveChanges();
    }
}
