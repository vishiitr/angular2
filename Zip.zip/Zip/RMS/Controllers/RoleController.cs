﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Collections.Generic;
using System;
using RMS.Models;
using ApplicationData;
using ApplicationData.Models;
using Business;
using Shared;

namespace RMS.Controllers
{
  [Route("api/[controller]/[action]")]
  public class RoleController : ApiController
  {
    IRoleFacade _roleFacade;

    public RoleController(IRoleFacade roleFacade)
    {
      _roleFacade = roleFacade;
    }

    [HttpGet]
    [ActionName("GetRoles")]
    public Result<IList<RoleDto>> GetRoles()
    {
      return _roleFacade.GetRoles();
    }

    [HttpGet]
    [ActionName("GetRole")]
    public Result<RoleDto> GetRole(int id)
    {
      return _roleFacade.GetRole(id);
    }

    [HttpPut]
    [ActionName("EditRole")]
    public bool EditRole([FromBody]RoleDto role)
    {
      try
      {
        _roleFacade.EditRole(role);
        return true;
      }
      catch
      {
        return false;
      }
    }

    [HttpDelete]
    [ActionName("DeleteRole")]
    public bool DeleteRole(int id)
    {
      try
      {
        _roleFacade.DeleteRole(id);
        return true;
      }
      catch
      {
        return false;
      }
    }

    [HttpPost("[action]")]
    public Result<RoleDto> AddRole([FromBody]RoleDto role)
    {
      return _roleFacade.AddRole(role);
    }

    [HttpPost("[action]")]
    [ActionName("UpdatePermissions")]
    public Result<bool> UpdatePermissions([FromBody] RoleFeaturePermissionDto request)
    {
      return null;
      //return _roleFacade.UpdateRoleFeaturePermission(request.FeaturePermissionIds, request.RoleId);
    }


  }
}
