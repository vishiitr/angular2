﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Collections.Generic;
using System;
using RMS.Models;
using Business;
using Shared;
using System.Linq;

namespace RMS.Controllers
{
  [Route("api/[controller]")]
  public class UserController : Controller
  {
    IUsersFacade _userFacade;
    public UserController(IUsersFacade userFacade)
    {
      _userFacade = userFacade;
    }

    [HttpGet("[action]")]
    public Result<IList<UsersDto>> GetUsers()
    {
      return _userFacade.GetUsers();
    }

    [HttpGet("[action]")]
    public UsersDto GetUser(int id)
    {
      return _userFacade.GetUser(id);
    }

    [HttpPut("[action]")]
    public bool EditUser([FromBody]UsersDto user)
    {
      try
      {
        _userFacade.EditUser(user);
        return true;
      }
      catch(Exception ex)
      {
        return false;
      }
    }

    [HttpDelete("[action]")]
    public bool DeleteUser(int id)
    {
      try
      {
        _userFacade.DeleteUser(id);
        return true;
      }
      catch
      {
        return false;
      }
    }

    [HttpPost("[action]")]
    public Result<UsersDto> CreateUser([FromBody]UsersDto user)
    {
      return _userFacade.AddUser(user);
    }
  }
}
