﻿namespace RMS.Controllers
{
  public class RoleUpdatePermissionRequest
  {
    public string FeaturePermissionIds { get; set; }

    public int RoleId { get; set; }
  }
}