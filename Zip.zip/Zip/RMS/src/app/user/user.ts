﻿export class User {
    EmailId: string;    
    Id: number;
    LastUpdate: "0001-01-01T00:00:00";
    LoginId: string;
    Name: string;
    Password: string;
    RoleId: number;
}