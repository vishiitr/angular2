﻿import { Component, OnInit } from '@angular/core';
import { RoleService } from "./role.service";
// import { TableData } from '../md/md-table/md-table.component';
declare let $: any;

@Component({
    moduleId: module.id,
    selector: 'regular-table-cmp',
    templateUrl: 'userRole.component.html',
    styles: [`
    `]
})

export class UserRoleComponent implements OnInit {
    public roleDetailTable;
    public roles;

    constructor(private roleService: RoleService) { }

    ngOnInit() {
        this.roles = {
            headerRow: ['Id', 'Name', 'Action'],
            dataRows: []
        }
        this.roleService.getRoles().subscribe(resp => this.roles.dataRows = resp.Data);
        this.roleDetailTable = {
            headerRow: ['Name', 'Read', 'Update', 'Create', 'Delete'],
            dataRows: []
        };
    }

    showData() {
        this.roleService.savePermission({ "RoleId": 2, "FeaturePermissions": this.roleDetailTable.dataRows }).subscribe();
        console.log(this.roleDetailTable.dataRows);
    }
    viewRolePermission(roleId) {
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#roleModal').modal('show');
        this.roleService.getRole(roleId).subscribe(role => {
            var features = Object.keys(role.Data.FeaturePermissions);
            for (var i = 0; i < features.length; i++) {
                var permissionArray: any = {};
                permissionArray.featureName = features[i];
                if (role.Data.FeaturePermissions[features[i]].find(o => o.PermissionName.toLowerCase() == "read"))
                    permissionArray.readPermission = true;
                else
                    permissionArray.readPermission = false;

                if (role.Data.FeaturePermissions[features[i]].find(o => o.PermissionName.toLowerCase() == "update"))
                    permissionArray.updatePermission = true;
                else
                    permissionArray.updatePermission = false;

                if (role.Data.FeaturePermissions[features[i]].find(o => o.PermissionName.toLowerCase() == "create"))
                    permissionArray.createPermissionName = true;
                else
                    permissionArray.createPermissionName = false;

                if (role.Data.FeaturePermissions[features[i]].find(o => o.PermissionName.toLowerCase() == "delete"))
                    permissionArray.deletePermissionName = true;
                else
                    permissionArray.deletePermissionName = false;

                this.roleDetailTable.dataRows.push(permissionArray);
            }
            var abc = this.roleDetailTable.dataRows;
            console.log(this.roleDetailTable.dataRows);
        });
    }


}
