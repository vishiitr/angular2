﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { UserRoleComponent } from "./userRole.component";
import { UserComponent } from './user.component';

@NgModule({
    imports: [ RouterModule, FormsModule, CommonModule],
    declarations: [UserRoleComponent, UserComponent],
    exports: [UserRoleComponent],
})
export class UserModule {

}
