﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';

import { User } from './user';

@Injectable()
export class UserService {
    constructor(private http: Http) {
    }

    getUsers() {
        return this.http.get('/api/user/GetUsers').map((response: Response) => response.json());
    }

    getUser(id: number) {
        return this.http.get('/api/user/GetUser?id=' + id).map((response: Response) => response.json());
    }

    addUser(user: User) {
        return this.http.post('/api/user/CreateUser', user).map((response: Response) => response.json());
    }

    editUser(user: User) {
        return this.http.put('/api/user/EditUser?id=' + user.Id, user).map((response: Response) => response.json());
    }

    deleteUser(id: number) {
        return this.http.delete('/api/user/DeleteUser?id=' + id).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
}