﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map'

@Injectable()
export class UserService {

    readonly serviceBaseUrl: string = "http://localhost:4200/"

    constructor(private http: Http) { }

    getUsers(): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.get('/api/user/getusers', options)
            .map((response: Response) => {
                if (response.status == 200) {
                    console.log(response);
                    // set token property
                    return response.json().Data;
                } else {
                    return false;
                }
            });
    }

    getUser(id): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.get('/api/user/getuser?id=' + id, options)
            .map((response: Response) => {
                if (response.status == 200) {
                    // set token property
                    return response.json();
                } else {
                    return false;
                }
            });
    }

    editUser(user): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post('/api/user/editUser', JSON.stringify(user), options)
            .map((response: Response) => {
                if (response.status == 200) {
                    // set token property
                    return response.json();
                } else {
                    return false;
                }
            });
    }
    addUser(user): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post('/api/user/AddUser', JSON.stringify(user), options)
            .map((response: Response) => {
                if (response.status == 200) {
                    // set token property
                    return response.json().Data;
                } else {
                    return false;
                }
            });
    }
    deleteUser(id): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.delete('/api/user/DeleteUser?id=' + id, options)
            .map((response: Response) => {
                if (response.status == 200) {
                    // set token property
                    return response.json();
                } else {
                    return false;
                }
            });
    }
}
