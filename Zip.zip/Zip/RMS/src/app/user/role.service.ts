﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';


@Injectable()
export class RoleService {

    constructor(private http: Http) { }

    getRoles() {
        return this.http.get('/api/Role/GetRoles').map((response: Response) => response.json());
    }

    getRole(id: number) {
        return this.http.get('/api/Role/GetRole?id=' + id).map((response: Response) => response.json());
    }

    savePermission(permssions: any) {
        return this.http.post('/api/Role/UpdatePermissions', permssions);
    }
}
