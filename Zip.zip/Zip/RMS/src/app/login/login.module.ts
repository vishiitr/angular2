import { NgModule, ModuleWithProviders } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { LoginComponent } from "./login.component";

@NgModule({
    imports: [RouterModule, FormsModule, CommonModule],
    declarations: [LoginComponent],
    exports: [LoginComponent],
})
export class LoginModule {

}
