﻿namespace Business
{
    using System.Collections.Generic;
    using System.Linq;

    using FluentValidation;
    using FluentValidation.Internal;
    using FluentValidation.Results;

    /// <summary>
    /// Represents the Validator Collection
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ValidatorCollection<T> : AbstractValidator<T>
    {
        /// <summary>
        /// Gets or sets a list of properties to validate for the given instance.
        /// If this list is empty, entire object will be validated.
        /// </summary>
        /// <value>The properties to validate.</value>
        protected IEnumerable<string> PropertiesToValidate
        {
            get;
            set;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatorCollection{T}" /> class.
        /// </summary>
        public ValidatorCollection()
        {
            PropertiesToValidate = new List<string>();
        }

        /// <summary>
        /// Validates the provided instance. If only some properties need to be validated, set PropertiesToValidate before calling this method.
        /// </summary>
        /// <param name="instance">The instance to be validated</param>
        /// <returns>The validation result</returns>
        public ValidationResult ValidateInstance(T instance)
        {
            if (PropertiesToValidate.Any())
            {
                return this.Validate(new ValidationContext<T>(instance, new PropertyChain(), new MemberNameValidatorSelector(PropertiesToValidate)));
            }

            return this.Validate(instance);
        }
    }
}
