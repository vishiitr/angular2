﻿using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    /// <summary>
    /// Represents the FacadeBase
    /// </summary>
    public abstract class FacadeBase : IFacade
    {
        //protected ILogger _logger;
        /// <summary>
        /// Initializes a new instance of the <see cref="FacadeBase"/> class.
        /// </summary>
        //protected FacadeBase(ILogger logger)
        //{
        //    _logger = logger;
        //}

        protected Result<O> Invoke<O>(Func<Result<O>> perform)
        {
            return this.Invoke<O, VoidResult>(VoidResult.Default, null, perform);
        }

        /// <summary>
        /// Invokes the specified data.
        /// </summary>
        /// <typeparam name="O"></typeparam>
        /// <typeparam name="I"></typeparam>
        /// <param name="data">The data.</param>
        /// <param name="validator">The validator.</param>
        /// <param name="perform">The perform.</param>
        /// <returns>Result&lt;O&gt;.</returns>
        protected Result<O> Invoke<O, I>(I data,
            ValidatorCollection<I> validator,
            Func<Result<O>> perform)
        {
            Result<O> result = null;

            bool isValid = false;

            // Check if user inputs are valid
            if (validator != null)
            {
                ValidationResult validationResult = validator.ValidateInstance(data);
                isValid = validationResult.IsValid;

                if (!validationResult.IsValid)
                {
                    result = Result<O>.CreateFailureResult(validationResult, FailureType.Validation);
                }
            }
            else
            {
                isValid = true;
            }

            if (isValid)
            {
                try
                {
                    result = perform();

                    if (result == null)
                        result = Result<O>.CreateErrorResult("Null result object");
                }
                catch (FailureException<string> ex)
                {
                    result = Result<O>.CreateFailureResult(ex);
                }
                catch (FailureException ex)
                {
                    result = Result<O>.CreateFailureResult(ex);
                }
                catch (Exception ex)
                {
                    result = Result<O>.CreateExceptioResult(ex);
                }

            }

            return result;
        }
    }
}
