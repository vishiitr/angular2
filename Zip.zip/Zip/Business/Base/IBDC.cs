﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    /// <summary>
    /// Defines the contract for implementing IBDC
    /// </summary>
    public interface IBDC
    {
        // Empty 
    }
}