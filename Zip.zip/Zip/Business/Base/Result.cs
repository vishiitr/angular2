﻿using FluentValidation.Results;
using System;
using System.Collections.Generic;

namespace Business
{
    /// <summary>
    /// Represents the Result
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Result<T>
    {
        /// <summary>
        /// Gets the data.
        /// </summary>
        /// <value>The data.</value>
        public T Data { get; private set; }
        /// <summary>
        /// Gets the type of the result.
        /// </summary>
        /// <value>The type of the result.</value>
        public ResultType ResultType { get; private set; }

        /// <summary>
        /// Gets the type of the failure.
        /// </summary>
        /// <value>The type of the failure.</value>
        public FailureType FailureType { get; private set; }
        /// <summary>
        /// Gets the exception.
        /// </summary>
        /// <value>The exception.</value>
        public Exception Exception { get; private set; }

        /// <summary>
        /// Gets the validation error.
        /// </summary>
        /// <value>The validation error.</value>
        public ValidationError ValidationError { get; private set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public string Code { get; set; }
        /// <summary>
        /// Gets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; private set; }
        /// <summary>
        /// Gets the extra information.
        /// </summary>
        /// <value>The extra information.</value>
        public string ExtraInformation { get; private set; }

        /// <summary>
        /// Prevents a default instance of the <see cref="Result{T}"/> class from being created.
        /// </summary>
        private Result()
        {
            // Prevent direct creation
        }

        /// <summary>
        /// Creates the success result.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateSuccessResult(T data)
        {
            return new Result<T>()
            {
                Data = data,
                ResultType = ResultType.Success,
            };
        }

        /// <summary>
        /// Creates the error result.
        /// </summary>
        /// <param name="errorMessage">The error message.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateErrorResult(string errorMessage)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Error,
                Message = errorMessage,
            };
        }

        /// <summary>
        /// Creates the error result.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateErrorResult(Exception ex)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Error,
                Exception = ex,
                Message = ex.Message,
            };
        }

        /// <summary>
        /// Creates the failure result.
        /// </summary>
        /// <param name="failureMessage">The failure message.</param>
        /// <param name="failureType">Type of the failure.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateFailureResult(string failureMessage, FailureType failureType)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Failure,
                FailureType = failureType,
                Message = failureMessage,
            };
        }

        /// <summary>
        /// Creates the failure result.
        /// </summary>
        /// <param name="validationResult">The validation result.</param>
        /// <param name="failureType">Type of the failure.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateFailureResult(ValidationResult validationResult, FailureType failureType)
        {
            var validationError = new ValidationError() { Code = "", Message = "", ValidationErrorItems = new List<ValidationErrorItem>() };
            foreach (var failure in validationResult.Errors)
            {
                var code = failure.CustomState as ValidationState;
                validationError.ValidationErrorItems.Add(new ValidationErrorItem() { Code = code.Code, Field = failure.PropertyName, Message = failure.ErrorMessage });
            }

            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Failure,
                FailureType = failureType,
                ValidationError = validationError,
            };
        }

        /// <summary>
        /// Creates the failure result.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateFailureResult(FailureException<string> ex)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Failure,
                FailureType = ex.FailureType,
                Message = ex.ErrorMessage,
                Code = ex.ErrorCode,
                ExtraInformation = ex.ExtraInformation
            };
        }

        /// <summary>
        /// Creates the failure result.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateFailureResult(FailureException ex)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Failure,
                FailureType = ex.FailureType,
                Message = ex.ErrorMessage,
                Code = ex.ErrorCode
            };
        }

        /// <summary>
        /// Creates the failure result.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns>Result&lt;T&gt;.</returns>
        public static Result<T> CreateExceptioResult(Exception ex)
        {
            return new Result<T>()
            {
                Data = default(T),
                ResultType = ResultType.Error,
                Message = ex.Message,
                Exception = ex
            };
        }
    }
}
