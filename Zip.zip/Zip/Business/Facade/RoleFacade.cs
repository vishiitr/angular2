﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Business
{
    public class RoleFacade : FacadeBase, IRoleFacade
    {
        private IRoleBDC _roleBDC;

        public RoleFacade()
        {
            this._roleBDC = new RoleBDC();
        }

        public Result<RoleDto> AddRole(RoleDto roledto)
        {
            Result<RoleDto> result = this.Invoke<RoleDto>
                   (
                       () =>
                       {
                           var role = _roleBDC.AddRole(roledto);
                           var roleDto = new RoleDto
                           {
                               Id = role.Id,
                               Name = role.Name,
                               Enabled = role.Enabled
                           };
                           return Result<RoleDto>.CreateSuccessResult(roleDto);
                       }

                   );
            return result;
        }

        public void DeleteRole(int id)
        {
            this._roleBDC.DeleteRole(id);
        }

        public void EditRole(RoleDto user)
        {
            this._roleBDC.EditRole(user);
        }

        public Result<RoleDto> GetRole(int id)
        {
            Result<RoleDto> result = this.Invoke<RoleDto>
                   (
                       () =>
                       {
                           var role = this._roleBDC.GetRole(id);
                           var roleDto = new RoleDto
                           {
                               Id = role.Id,
                               Name = role.Name,
                               Enabled = role.Enabled,
                               FeaturePermissions = new Dictionary<string, List<FeaturePermissionDto>>()
                           };
                           foreach (var item in role.RoleFeaturePermission)
                           {
                               if (!roleDto.FeaturePermissions.ContainsKey(item.FeaturePermission.Feature.Title))
                               {
                                   roleDto.FeaturePermissions.Add(item.FeaturePermission.Feature.Title, new List<FeaturePermissionDto>() {
                                       new FeaturePermissionDto
                                           {
                                               FeaturePermissionId = item.FeaturePermissionId,
                                               PermissionName = item.FeaturePermission.Permission.Name
                                           }});

                               }
                               else
                               {
                                   roleDto.FeaturePermissions[item.FeaturePermission.Feature.Title].Add(new FeaturePermissionDto
                                   {
                                       FeaturePermissionId = item.FeaturePermissionId,
                                       PermissionName = item.FeaturePermission.Permission.Name
                                   });
                               }
                           }
                           return Result<RoleDto>.CreateSuccessResult(roleDto);
                       }

                   );
            return result;


        }

        public Result<IList<RoleDto>> GetRoles()
        {
            Result<IList<RoleDto>> result = this.Invoke<IList<RoleDto>>
                   (
                       () =>
                       {
                           var roles = this._roleBDC.GetRoles();
                           var roleDto = roles.Select(t => new RoleDto
                           {
                               Id = t.Id,
                               Name = t.Name,
                               Enabled = t.Enabled
                           }).ToList();
                           return Result<IList<RoleDto>>.CreateSuccessResult(roleDto);
                       }

                   );
            return result;
        }

        public Result<bool> UpdateRoleFeaturePermission(string listOfPermissionId, int roleId)
        {
            Result<bool> result = this.Invoke<bool>
                   (
                       () =>
                       {
                           var bdcResult = _roleBDC.UpdateRoleFeaturePermission(listOfPermissionId, roleId);
                           return Result<bool>.CreateSuccessResult(bdcResult);
                       }
                   );

            return result;
        }
    }
}