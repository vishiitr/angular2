﻿using ApplicationData;
using ApplicationData.Models;
using System.Collections.Generic;
using System.Linq;
using Shared;
using System;
using Microsoft.EntityFrameworkCore;

namespace Business
{
    public class RoleBDC : BDCBase, IRoleBDC
    {
        private IRoleRepository _roleRepository;

        public RoleBDC()
        {
            this._roleRepository = new RoleRepository();
        }

        public Role AddRole(RoleDto role)
        {
            var roleForDb = new Role();
            roleForDb.Id = role.Id;
            roleForDb.Name = role.Name;
            roleForDb.Description = role.Description;
            _roleRepository.Insert(roleForDb);
            _roleRepository.SaveChanges();

            return roleForDb;
        }

        public void DeleteRole(int id)
        {
            var roleFromDb = _roleRepository.Get(id);
            _roleRepository.Delete(roleFromDb);
            _roleRepository.SaveChanges();
        }

        public void EditRole(RoleDto role)
        {
            var roleFromDb = _roleRepository.Get(role.Id);
            roleFromDb.Id = role.Id;
            roleFromDb.Name = role.Name;
            roleFromDb.Description = role.Description;
            _roleRepository.Update(roleFromDb);
            _roleRepository.SaveChanges();
        }

        public Role GetRole(int id)
        {
            return _roleRepository.GetRole(id);
        }

        public IList<Role> GetRoles()
        {
            return _roleRepository.GetAll().ToList();
        }

        public bool UpdateRoleFeaturePermission(string listOfPermissionId, int roleId)
        {
            return _roleRepository.UpdateRoleFeaturePermission(listOfPermissionId, roleId);
        }
    }
}
