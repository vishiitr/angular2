﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IRoleBDC
    {
        IList<Role> GetRoles();

        Role GetRole(int id);

        void EditRole(RoleDto user);

        void DeleteRole(int id);

        Role AddRole(RoleDto user);

        bool UpdateRoleFeaturePermission(string listOfPermissionId, int roleId);
    }
}
