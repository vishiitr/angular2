import {Injectable} from "@angular/core";
import { ConnectionBackend, RequestOptions, Request, RequestOptionsArgs, Response, Http, Headers} from "@angular/http";
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders } from '@angular/common/http'
import {Observable} from "rxjs/Rx";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    intercept(req:HttpRequest<any>, next:HttpHandler):Observable<HttpEvent<any>>{
        let heads;
        heads = {'Content-Type':'application/json', 'Authorization': '1234'};
        const headers = new HttpHeaders(heads);
        const authReq = req.clone({headers:headers, reportProgress:false});
        return next.handle(authReq);
    }
}