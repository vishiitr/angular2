import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { JwtHelper } from 'angular2-jwt';
import { AuthToken } from './AuthToken'
// import {AppSettings} from '../../app.settings';
import 'rxjs/add/operator/map'


@Injectable()
export class AuthService{

  readonly crntUserKey: string = "crntUser";
  readonly serviceBaseUrl:string = "http://localhost:4200/"

  jwtHelper: JwtHelper;
  
  constructor(private http: Http) {
    this.jwtHelper = new JwtHelper();
   }  

  login(userId:string, password:string): Observable<boolean>{
      let token:AuthToken;
      this.setUserToken(token);
      return this.http.post('/api/authenticate', JSON.stringify({ userId: userId, password: password }))
      .map((response: Response) => {
          // login successful if there's a jwt token in the response
          debugger;
          if (response.status == 200) {
              // set token property
              token = response.json();
              // store username and jwt token in local storage to keep user logged in between page refreshes
              localStorage.setItem(this.crntUserKey, JSON.stringify(token));

              // return true to indicate successful login
              return true;
          } else {
              // return false to indicate failed login
              return false;
          }
      });
  }
  
  IsCurrentUserAuthenticated() : boolean {
        let authenticationStatus : boolean = false;
        let testResp:any = localStorage.getItem(this.crntUserKey);
        
        if(testResp!=null){
            let token:AuthToken = JSON.parse(localStorage.getItem(this.crntUserKey));
            
                    if(token.access_token.length > 0
                        //&& !this.jwtHelper.isTokenExpired(token.access_token)
                    ){
                        authenticationStatus = true;
                    }
        }      

        return authenticationStatus;
  }

  logOut(){
      localStorage.removeItem(this.crntUserKey);
  }

  private setUserToken(token:AuthToken):boolean{
        localStorage.setItem(this.crntUserKey, JSON.stringify(token));
        return true;
  }
}
