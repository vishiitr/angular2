import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth/auth.service';
import { RouterModule } from '@angular/router'
import { AuthGuard } from './guards/auth.guard';
import { LoginGuard } from './guards/login.guard';
import { AuthInterceptor } from './auth/authInterceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

@NgModule({
    imports: [CommonModule, FormsModule, RouterModule],
    declarations: [],
    exports:[],  
    providers : [AuthService, AuthGuard, LoginGuard] 
})
export class SharedModule {
    static forRoot(): ModuleWithProviders{
        return {
            ngModule: SharedModule,
            providers:[
                AuthService,
                AuthGuard,
                LoginGuard,
                {
                  provide:HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi : true  
                }
            ]
        };
    }
}
