import { NgModule, ModuleWithProviders } from '@angular/core';
import { SidebarModule } from './sidebar/sidebar.module'
import { NavbarComponent } from './navbar/navbar.component'
import { LayoutComponent } from "./layout.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [SidebarModule, RouterModule, FormsModule, CommonModule],
    declarations: [LayoutComponent, NavbarComponent],
    exports: [LayoutComponent, NavbarComponent],
})
export class LayoutModule {

}
