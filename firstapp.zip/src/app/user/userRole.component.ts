import { Component, OnInit } from '@angular/core';
// import { TableData } from '../md/md-table/md-table.component';

@Component({
    moduleId: module.id,
    selector: 'regular-table-cmp',
    templateUrl: 'userRole.component.html',
    styles: [`
    `]
})

export class UserRoleComponent implements OnInit {
    public tableData1;

    ngOnInit() {
        this.tableData1 = {
            headerRow: ['Name', 'Read', 'Update', 'Create', 'Delete'],
            dataRows: [
                [0, 'Dakota Rice', true, true, true, false],
                [1, 'Minerva Hooper', false, false, true, true],
                [0, 'Sage Rodriguez', true, false, true, true],
                [0, 'Philip Chaney', false, false, true, true],
                [1, 'Doris Greene', true, true, true, false],
                [1, 'Mason Porter', false, true, true, true]
            ]
        };
    }

    showData() {
        console.log(this.tableData1);
    }
}
