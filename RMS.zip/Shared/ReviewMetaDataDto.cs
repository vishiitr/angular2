﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared
{
    public class ReviewMetaDataDto
    {
        public IList<ChannelDto> Channels { get; set; }
        public IList<PropertyDto> Properties { get; set; }
        public IList<LanguageDto> Languages { get; set; }
    }
}
