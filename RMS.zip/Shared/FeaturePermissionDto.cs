﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared
{
    public class FeaturePermissionDto
    {
        public int FeaturePermissionId { get; set; }
        public string PermissionName { get; set; }
        //public string FeatureName { get; set; }
    }
}
