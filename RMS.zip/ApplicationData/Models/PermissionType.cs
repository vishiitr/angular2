﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace ApplicationData.Models
{
    public partial class PermissionType
    {
        public PermissionType()
        {
            FeaturePermission = new HashSet<FeaturePermission>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public BitArray Enabled { get; set; }
        public DateTime LastUpdate { get; set; }

        public virtual ICollection<FeaturePermission> FeaturePermission { get; set; }
    }
}
