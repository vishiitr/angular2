﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace ApplicationData.Models
{
    public partial class Department
    {
        public Department()
        {
            Users = new HashSet<Users>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public BitArray Enabled { get; set; }
        public DateTime LastUpdate { get; set; }

        public virtual ICollection<Users> Users { get; set; }
    }
}
