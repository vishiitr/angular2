﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class ReviewComment
    {
        public long Id { get; set; }
        public long? ReviewId { get; set; }
        public string Details { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual Review Review { get; set; }
    }
}
