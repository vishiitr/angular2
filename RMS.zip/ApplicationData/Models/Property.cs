﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Property
    {
        public Property()
        {
            Review = new HashSet<Review>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime LastUpdated { get; set; }

        public virtual ICollection<Review> Review { get; set; }
    }
}
