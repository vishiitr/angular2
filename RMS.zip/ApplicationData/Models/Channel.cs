﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Channel
    {
        public Channel()
        {
            Review = new HashSet<Review>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual ICollection<Review> Review { get; set; }
    }
}
