﻿
using ApplicationData.Models;
using System.Collections.Generic;

namespace ApplicationData
{
    /// <summary>
    /// Defines the contract for implementing [todo]
    /// </summary>
    public interface IReviewRepository : IRepository<Review>
    {
        //Role GetRole(int id);

        //bool UpdateRoleFeaturePermission(string listOfPermissionId, int roleId);
    }
}
