﻿using ApplicationData.Models;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace ApplicationData
{
    /// <summary>
    /// Represents the Application Version Repository
    /// </summary>
    public class DepartmentRepository : RepositoryBase<Department>, IDepartmentRepository
    {
        public DepartmentRepository()
        {
        }
    }
}
