﻿
using ApplicationData.Models;
using System.Collections.Generic;

namespace ApplicationData
{
    /// <summary>
    /// Defines the contract for implementing [todo]
    /// </summary>
    public interface IDepartmentRepository : IRepository<Department>
    {
    }
}
