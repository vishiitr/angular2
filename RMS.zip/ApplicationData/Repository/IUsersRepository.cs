﻿
using ApplicationData.Models;

namespace ApplicationData
{
    /// <summary>
    /// Defines the contract for implementing [todo]
    /// </summary>
    public interface IUsersRepository : IRepository<Users>
    {        
    }
}
