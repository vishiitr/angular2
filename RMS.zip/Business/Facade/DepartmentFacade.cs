﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;
using System;
using Business.BDC;

namespace Business
{
    public class DepartmentFacade : FacadeBase, IDepartmentFacade
    {
        private IDepartmentBDC _departmentBDC;

        public DepartmentFacade()
        {
            this._departmentBDC = new DepartmentBDC();
        }

        public Result<DepartmentDto> AddDepartment(DepartmentDto departmentdto)
        {
            Result<DepartmentDto> result = this.Invoke<DepartmentDto>
                   (
                       () =>
                       {
                           var department = _departmentBDC.AddDepartment(departmentdto);
                           var departmentDto = new DepartmentDto
                           {
                               Id = department.Id,
                               Name = department.Name,
                               Description = department.Description,
                               //Enabled = role.Enabled
                           };
                           return Result<DepartmentDto>.CreateSuccessResult(departmentDto);
                       }

                   );
            return result;
        }

        public void DeleteDepartment(int id)
        {
            this._departmentBDC.DeleteDepartment(id);
        }

        public void EditDepartment(DepartmentDto depart)
        {
            this._departmentBDC.EditDepartment(depart);
        }

        public Result<IList<DepartmentDto>> GetDepartments()
        {
            Result<IList<DepartmentDto>> result = this.Invoke<IList<DepartmentDto>>
                   (
                       () =>
                       {
                           var departments = this._departmentBDC.GetDepartments();
                           var departmentDto = departments.Select(t => new DepartmentDto
                           {
                               Id = t.Id,
                               Name = t.Name,
                               //Enabled = t.Enabled,
                               Description = t.Description
                           }).ToList();
                           return Result<IList<DepartmentDto>>.CreateSuccessResult(departmentDto);
                       }

                   );
            return result;
        }
    }
}