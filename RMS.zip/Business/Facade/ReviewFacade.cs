﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Business
{
    public class ReviewFacade : FacadeBase, IReviewFacade
    {
        private IReviewBDC _reviewBDC;

        public ReviewFacade()
        {
            this._reviewBDC = new ReviewBDC();
        }

        public Result<ReviewDto> AddReview(ReviewDto reviewToAdd)
        {
            Result<ReviewDto> result = this.Invoke<ReviewDto>
                   (
                       () =>
                       {
                           var review = _reviewBDC.AddReview(reviewToAdd);
                           var reviewDto = new ReviewDto
                           {
                               Id = review.Id,
                               Description = review.Description,
                               AssignedTo = review.AssignedTo,
                               ChannelId = review.ChannelId,
                               PropertyId = review.PropertyId,
                               LanguageId = review.LanguageId,
                               Title = review.Title,
                               Rating = review.Rating,
                               Score = review.Score,
                               Type = review.Type,
                           };
                           return Result<ReviewDto>.CreateSuccessResult(reviewDto);
                       }

                   );
            return result;
        }

        public void DeleteReview(int id)
        {
            this._reviewBDC.DeleteReview(id);
        }

        public void EditReview(ReviewDto review)
        {
            this._reviewBDC.EditReview(review);
        }

        public Result<ReviewDto> GetReview(long id)
        {
            Result<ReviewDto> result = this.Invoke<ReviewDto>
                   (
                       () =>
                       {
                           var review = this._reviewBDC.GetReview(id);
                           var reviewDto = new ReviewDto
                           {
                               Id = review.Id,
                               Description = review.Description,
                               //AssignedTo = review.AssignedTo,
                               ChannelId = review.ChannelId,
                               PropertyId = review.PropertyId,
                               LanguageId = review.LanguageId,
                               Title = review.Title,
                               Rating = review.Rating,
                               Score = review.Score,
                               Type = review.Type,
                           };
                           
                           return Result<ReviewDto>.CreateSuccessResult(reviewDto);
                       }

                   );
            return result;


        }

        //public Result<IList<ReviewDto>> GetReview()
        //{
        //    Result<IList<ReviewDto>> result = this.Invoke<IList<ReviewDto>>
        //           (
        //               () =>
        //               {
        //                   var reviews = this._reviewBDC.GetReviews();
        //                   var reviewDtos = reviews.Select(t => new ReviewDto
        //                   {
        //                       Id = t.Id,
        //                       Description = t.Description
        //                   }).ToList();
        //                   return Result<IList<ReviewDto>>.CreateSuccessResult(reviewDtos);
        //               }

        //           );
        //    return result;
        //}

        public Result<IList<ReviewDto>> GetReviews()
        {
            Result<IList<ReviewDto>> result = this.Invoke<IList<ReviewDto>>
                   (
                       () =>
                       {
                           var reviews = this._reviewBDC.GetReviews();
                           var reviewDtos = reviews.Select(t => new ReviewDto
                           {
                               Id = t.Id,
                               Description = t.Description,
                               Status = new ReviewStatusDto { Id = t.StatusNavigation.Id, Title = t.StatusNavigation.Title },
                               StatusId = t.StatusNavigation.Id,
                               Title = t.Title,
                               Score = t.Score,
                               PropertyId = t.PropertyId,
                               ReferenceNumber = t.ReferenceNumber,
                               Rating = t.Rating
                           }).ToList();
                           return Result<IList<ReviewDto>>.CreateSuccessResult(reviewDtos);
                       }
                   );
            return result;
        }

        public Result<ReviewMetaDataDto> GetReviewMetaData()
        {
            var result = this.Invoke<ReviewMetaDataDto>(() =>
            {
                var reviewMetadata = this._reviewBDC.GetReviewMetaData();
                var reviewMetadataDto = new ReviewMetaDataDto();

                var properties = (List<Property>)reviewMetadata.Properties;
                reviewMetadataDto.Properties = properties.Select(t => new PropertyDto
                {
                    Address = t.Address,
                    DateCreated = t.DateCreated,
                    Id = t.Id,
                    Name = t.Name
                }).ToList();

                var channels = (List<Channel>)reviewMetadata.Channels;
                reviewMetadataDto.Channels = channels.Select(t => new ChannelDto
                {
                    DateCreated = t.DateCreated,
                    Id = t.Id,
                    Name = t.Name
                }).ToList();

                var languages = (List<Language>)reviewMetadata.Languages;
                reviewMetadataDto.Languages = languages.Select(t => new LanguageDto
                {
                    DateCreated = t.DateCreated,
                    Id = t.Id,
                    Name = t.Name
                }).ToList();
                return Result<ReviewMetaDataDto>.CreateSuccessResult(reviewMetadataDto);
            });
            return result;
        }
    }
}