﻿
namespace Business
{
    /// <summary>
    /// Represents the Validation State
    /// </summary>
    public class ValidationState
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public string Code { get; set; }
    }
}
