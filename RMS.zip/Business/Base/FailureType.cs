﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    /// <summary>
    /// Enum FailureType
    /// </summary>
    public enum FailureType
    {
        /// <summary>
        /// The none
        /// </summary>
        None = 0,
        /// <summary>
        /// The unknown
        /// </summary>
        Unknown = 1, //500 
        /// <summary>
        /// The validation
        /// </summary>
        Validation = 2, //400
        /// <summary>
        /// The authorization
        /// </summary>
        Authorization = 3, //403
        /// <summary>
        /// The business error
        /// </summary>
        BusinessError = 4, //400
        /// <summary>
        /// The authentication
        /// </summary>
        Authentication = 5, //401
        /// <summary>
        /// The resource not found
        /// </summary>
        ResourceNotFound = 6 //404        
    }
}
