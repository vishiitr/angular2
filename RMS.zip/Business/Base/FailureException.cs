﻿using System;

namespace Business
{
    /// <summary>
    /// Represents the FailureException
    /// </summary>
    public class FailureException : Exception
    {
        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>The error code.</value>
        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        /// <value>The error message.</value>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the type of the failure.
        /// </summary>
        /// <value>The type of the failure.</value>
        public FailureType FailureType { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FailureException"/> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        /// <param name="failureType">Type of the failure.</param>
        public FailureException(string code, string message, FailureType failureType)
        {
            this.ErrorCode = code;
            this.ErrorMessage = message;
            this.FailureType = failureType;
        }
    }

    /// <summary>
    /// Represents the Failure Exceptions
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class FailureException<T> : FailureException
    {
        /// <summary>
        /// Gets or sets the extra information.
        /// </summary>
        /// <value>The extra information.</value>
        public T ExtraInformation { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FailureException{T}"/> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        /// <param name="failureType">Type of the failure.</param>
        /// <param name="extraInfo">The extra information.</param>
        public FailureException(string code, string message, FailureType failureType, T extraInfo)
            : base(code, message, failureType)
        {
            this.ExtraInformation = extraInfo;
        }
    }
}
