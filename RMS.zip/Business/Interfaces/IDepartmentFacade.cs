﻿using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IDepartmentFacade
    {
        Result<DepartmentDto> AddDepartment(DepartmentDto departmentdto);

        void DeleteDepartment(int id);

        void EditDepartment(DepartmentDto depart);

        Result<IList<DepartmentDto>> GetDepartments();
    }
}