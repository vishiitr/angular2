﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IReviewFacade
    {
        Result<IList<ReviewDto>> GetReviews();

        Result<ReviewDto> GetReview(long id);

        void EditReview(ReviewDto review);

        void DeleteReview(int id);

        Result<ReviewDto> AddReview(ReviewDto reviewDto);

        Result<ReviewMetaDataDto> GetReviewMetaData();
    }
}