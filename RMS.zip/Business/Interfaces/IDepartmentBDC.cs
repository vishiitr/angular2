﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    internal interface IDepartmentBDC
    {
        IList<Department> GetDepartments();

        Department AddDepartment(DepartmentDto department);

        void DeleteDepartment(int id);

        void EditDepartment(DepartmentDto department);
    }
}