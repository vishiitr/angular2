﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IReviewBDC
    {
        IList<Review> GetReviews();

        Review GetReview(long id);

        void EditReview(ReviewDto review);

        void DeleteReview(int id);

        Review AddReview(ReviewDto review);

        dynamic GetReviewMetaData();
    }
}
