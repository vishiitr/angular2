﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    /// <summary>
    /// Defines the contract for implementing IClientAppBDC
    /// </summary>
    public interface IUsersBDC
    {
        IList<Users> GetUsers();

        Users GetUser(int id);

        void EditUser(UsersDto user);

        void DeleteUser(int id);

        Users AddUser(UsersDto user);
    }
}
