﻿using ApplicationData;
using ApplicationData.Models;
using System.Collections.Generic;
using System.Linq;
using Shared;
using System;
using Microsoft.EntityFrameworkCore;
using NpgsqlTypes;
namespace Business
{
    public class ReviewBDC : BDCBase, IReviewBDC
    {
        private IReviewRepository _reviewRepository;

        public ReviewBDC()
        {
            this._reviewRepository = new ReviewRepository();
        }

        public Review AddReview(ReviewDto review)
        {
            var reviewForDb = new Review();
            reviewForDb.AssignedTo = review.AssignedTo;
            reviewForDb.ChannelId = review.ChannelId;
            reviewForDb.PropertyId = review.PropertyId;
            reviewForDb.LanguageId = review.LanguageId;
            reviewForDb.Title = review.Title;
            reviewForDb.Description = review.Description;
            reviewForDb.Rating = review.Rating;
            reviewForDb.Score = review.Score;
            reviewForDb.Type = review.Type;
            reviewForDb.Status = new RepositoryBase<ReviewStatus>().GetAll().First().Id;
            reviewForDb.LastUpdated = DateTime.Now;
            reviewForDb.DateCreated = DateTime.Now;
            reviewForDb = this._reviewRepository.Insert(reviewForDb);
            this._reviewRepository.SaveChanges();
            return reviewForDb;
        }

        public void DeleteReview(int id)
        {
            var reviewFromDb = this._reviewRepository.Get(id);
            this._reviewRepository.Delete(reviewFromDb);
            this._reviewRepository.SaveChanges();
        }

        public void EditReview(ReviewDto review)
        {
            var reviewFromDb = GetReview(review.Id);
            reviewFromDb.LanguageId = review.LanguageId;
            reviewFromDb.PropertyId = review.PropertyId.Value;
            reviewFromDb.ChannelId = review.ChannelId.Value;
            reviewFromDb.Title = review.Title;
            reviewFromDb.Description = review.Description;
            reviewFromDb.Score = review.Score;
            reviewFromDb.Rating= review.Rating;
            this._reviewRepository.Update(reviewFromDb);
            this._reviewRepository.SaveChanges();
        }

        public Review GetReview(long id)
        {
            var reviewFromDb = this._reviewRepository.GetAll().FirstOrDefault(t => t.Id == id);
            return reviewFromDb;
        }

        public IList<Review> GetReviews()
        {
            var reviewsFromDb = this._reviewRepository.GetAll().Include("StatusNavigation").ToList<Review>();
            return reviewsFromDb;
        }

        public dynamic GetReviewMetaData()
        {
            dynamic reviewMetaData = new System.Dynamic.ExpandoObject();
            reviewMetaData.Properties = new RepositoryBase<Property>().GetAll().ToList();
            reviewMetaData.Languages = new RepositoryBase<Language>().GetAll().ToList();
            reviewMetaData.Channels = new RepositoryBase<Channel>().GetAll().ToList();
            return reviewMetaData;
        }
    }
}
