﻿using ApplicationData;
using ApplicationData.Models;
using System.Collections.Generic;
using System.Linq;
using Shared;
using System;
using Microsoft.EntityFrameworkCore;
using NpgsqlTypes;
namespace Business
{
    public class RoleBDC : BDCBase, IRoleBDC
    {
        private IRoleRepository _roleRepository;

        public RoleBDC()
        {
            this._roleRepository = new RoleRepository();
        }

        public Role AddRole(RoleDto role)
        {
            var roleForDb = new Role();
            roleForDb.Id = role.Id;
            roleForDb.Name = role.Name;
            roleForDb.Description = role.Description;
            roleForDb.Enabled = new System.Collections.BitArray(new bool[] { true });
            var updatedRole = _roleRepository.Insert(roleForDb);
            _roleRepository.SaveChanges();

            return updatedRole;
        }

        public void DeleteRole(int id)
        {
            var roleFromDb = _roleRepository.GetAll().Where(t=>t.Id == id).Include("RoleFeaturePermission").First();
            //var roleFeaturePermission = new RepositoryBase<RoleFeaturePermission>();
            //foreach(var item in roleFromDb.RoleFeaturePermission)
            //{
            //    roleFeaturePermission.Delete(item);
            //}
            _roleRepository.Delete(roleFromDb);
            _roleRepository.SaveChanges();
        }

        public void EditRole(RoleDto role)
        {
            var roleFromDb = _roleRepository.Get(role.Id);
            roleFromDb.Id = role.Id;
            roleFromDb.Name = role.Name;
            roleFromDb.Description = role.Description;
            _roleRepository.Update(roleFromDb);
            _roleRepository.SaveChanges();
        }

        public Role GetRole(int id)
        {
            return _roleRepository.GetRole(id);
        }

        public IList<Role> GetRoles()
        {
            return _roleRepository.GetAll().ToList();
        }

        public IList<Feature> GetFeatures()
        {
            return new RepositoryBase<Feature>().GetAll().ToList();
        }

        public bool UpdateRoleFeaturePermission(RoleFeaturePermissionDto roleFeaturePermissionDto)
        {
            var featurePermissions = GetFeaturePermissions(roleFeaturePermissionDto);
            return _roleRepository.UpdateRoleFeaturePermission(string.Join(",", featurePermissions.Select(t => t.Id)), roleFeaturePermissionDto.RoleId);
        }

        private List<FeaturePermission> GetFeaturePermissions(RoleFeaturePermissionDto roleFeaturePermissionDto)
        {
            var featureNames = roleFeaturePermissionDto.FeaturePermissions.Select(t => t.featureName.ToLower());
            var features = new RepositoryBase<Feature>().GetAll().Where(s => featureNames.Contains(s.Title.ToLower())).ToList();
            var permissions = new RepositoryBase<PermissionType>().GetAll().ToList();
            var featurePermissions = new List<FeaturePermission>();
            foreach (var item in roleFeaturePermissionDto.FeaturePermissions)
            {
                var feature = features.First(t => t.Title.Equals(item.featureName));
                if (item.readPermission)
                    featurePermissions.Add(new FeaturePermission
                    {
                        FeatureId = feature.Id,
                        PermissionId = permissions.First(t => t.Name.Equals("read", StringComparison.CurrentCultureIgnoreCase)).Id
                    });
                if (item.updatePermission)
                    featurePermissions.Add(new FeaturePermission
                    {
                        FeatureId = feature.Id,
                        PermissionId = permissions.First(t => t.Name.Equals("update", StringComparison.CurrentCultureIgnoreCase)).Id
                    });
                if (item.createPermissionName)
                    featurePermissions.Add(new FeaturePermission
                    {
                        FeatureId = feature.Id,
                        PermissionId = permissions.First(t => t.Name.Equals("create", StringComparison.CurrentCultureIgnoreCase)).Id
                    });
                if (item.deletePermissionName)
                    featurePermissions.Add(new FeaturePermission
                    {
                        FeatureId = feature.Id,
                        PermissionId = permissions.First(t => t.Name.Equals("delete", StringComparison.CurrentCultureIgnoreCase)).Id
                    });
            }

            var featurePermissionsFromDb = from fp in (new RepositoryBase<FeaturePermission>().GetAll())
                                           join f in featurePermissions on new { fp.FeatureId, fp.PermissionId } equals new { f.FeatureId, f.PermissionId }
                                           select fp;
            return featurePermissionsFromDb.ToList();
        }
    }
}
