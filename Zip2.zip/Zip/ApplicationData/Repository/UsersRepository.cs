﻿using ApplicationData.Models;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace ApplicationData
{
    /// <summary>
    /// Represents the Application Version Repository
    /// </summary>
    public class UsersRepository : RepositoryBase<Users>, IUsersRepository
    {        
    }
}
