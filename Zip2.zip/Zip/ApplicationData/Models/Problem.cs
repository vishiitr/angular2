﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Problem
    {
        public Problem()
        {
            Investigation = new HashSet<Investigation>();
            ProblemInvestigation = new HashSet<ProblemInvestigation>();
        }

        public long Id { get; set; }
        public long? ReviewId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? Category { get; set; }
        public int? Status { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual ICollection<Investigation> Investigation { get; set; }
        public virtual ICollection<ProblemInvestigation> ProblemInvestigation { get; set; }
        public virtual ProblemCategory CategoryNavigation { get; set; }
        public virtual Review Review { get; set; }
        public virtual ProblemStatus StatusNavigation { get; set; }
    }
}
