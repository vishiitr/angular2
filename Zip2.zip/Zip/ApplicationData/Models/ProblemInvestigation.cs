﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class ProblemInvestigation
    {
        public long Id { get; set; }
        public long? ProblemId { get; set; }
        public long? InvestigationId { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual Investigation Investigation { get; set; }
        public virtual Problem Problem { get; set; }
    }
}
