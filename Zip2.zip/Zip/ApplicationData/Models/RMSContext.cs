﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApplicationData.Models
{
    public partial class RMSContext : DbContext
    {
        public virtual DbSet<Channel> Channel { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Feature> Feature { get; set; }
        public virtual DbSet<FeaturePermission> FeaturePermission { get; set; }
        public virtual DbSet<Guest> Guest { get; set; }
        public virtual DbSet<Investigation> Investigation { get; set; }
        public virtual DbSet<InvestigationStatus> InvestigationStatus { get; set; }
        public virtual DbSet<Language> Language { get; set; }
        public virtual DbSet<PermissionType> PermissionType { get; set; }
        public virtual DbSet<Problem> Problem { get; set; }
        public virtual DbSet<ProblemCategory> ProblemCategory { get; set; }
        public virtual DbSet<ProblemInvestigation> ProblemInvestigation { get; set; }
        public virtual DbSet<ProblemStatus> ProblemStatus { get; set; }
        public virtual DbSet<Property> Property { get; set; }
        public virtual DbSet<Reservation> Reservation { get; set; }
        public virtual DbSet<Review> Review { get; set; }
        public virtual DbSet<ReviewComment> ReviewComment { get; set; }
        public virtual DbSet<ReviewResponse> ReviewResponse { get; set; }
        public virtual DbSet<ReviewStatus> ReviewStatus { get; set; }
        public virtual DbSet<ReviewTranslation> ReviewTranslation { get; set; }
        public virtual DbSet<ReviewType> ReviewType { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RoleFeaturePermission> RoleFeaturePermission { get; set; }
        public virtual DbSet<Translation> Translation { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<UsersRole> UsersRole { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
            optionsBuilder.UseNpgsql(@"Host=localhost;Database=RMS;Username=postgres;Password=Password");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Channel>(entity =>
            {
                entity.ToTable("channel");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('channel_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("department");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Enabled)
                    .IsRequired()
                    .HasColumnName("enabled")
                    .HasColumnType("bit");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Feature>(entity =>
            {
                entity.ToTable("feature");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_bookmark_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasColumnName("title")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<FeaturePermission>(entity =>
            {
                entity.ToTable("feature_permission");

                entity.HasIndex(e => new { e.FeatureId, e.PermissionId })
                    .HasName("UNQ_feature_permisslon")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_bookmark_permission_id'::regclass)");

                entity.Property(e => e.FeatureId).HasColumnName("feature_id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.PermissionId).HasColumnName("permission_id");

                entity.HasOne(d => d.Feature)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.FeatureId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK1_feature_permission");

                entity.HasOne(d => d.Permission)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.PermissionId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK2_feature_permission");
            });

            modelBuilder.Entity<Guest>(entity =>
            {
                entity.ToTable("guest");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('guest_id_seq'::regclass)");

                entity.Property(e => e.Address)
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.DateCreated)
                    .HasColumnName("Date_Created")
                    .HasColumnType("time");

                entity.Property(e => e.Email)
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.LastUpdated)
                    .HasColumnName("Last_Updated")
                    .HasColumnType("time");

                entity.Property(e => e.MiscDetails)
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Phone)
                    .HasColumnType("varchar")
                    .HasMaxLength(15);
            });

            modelBuilder.Entity<Investigation>(entity =>
            {
                entity.ToTable("investigation");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('investigation_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Reason)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Resolution)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.SupervisorFeedback)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.HasOne(d => d.AssignedPerson)
                    .WithMany(p => p.InvestigationAssignedPerson)
                    .HasForeignKey(d => d.AssignedPersonId)
                    .HasConstraintName("investigation_userId_FKey1");

                entity.HasOne(d => d.Problem)
                    .WithMany(p => p.Investigation)
                    .HasForeignKey(d => d.ProblemId)
                    .HasConstraintName("investigation_problemId_FKey2");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.Investigation)
                    .HasForeignKey(d => d.Status)
                    .HasConstraintName("investigation_investigationStatusId_FKey3");

                entity.HasOne(d => d.Supervisor)
                    .WithMany(p => p.InvestigationSupervisor)
                    .HasForeignKey(d => d.SupervisorId)
                    .HasConstraintName("investigation_userId_FKey4");
            });

            modelBuilder.Entity<InvestigationStatus>(entity =>
            {
                entity.ToTable("investigation_status");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('investigation_status_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<Language>(entity =>
            {
                entity.ToTable("language");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('language_id_seq'::regclass)");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasColumnType("bpchar")
                    .HasMaxLength(5);

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<PermissionType>(entity =>
            {
                entity.ToTable("permission_type");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_permission_type_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Enabled)
                    .IsRequired()
                    .HasColumnName("enabled")
                    .HasColumnType("bit")
                    .HasDefaultValueSql("B'1'::\"bit\"");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Problem>(entity =>
            {
                entity.ToTable("problem");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('problem_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.HasOne(d => d.CategoryNavigation)
                    .WithMany(p => p.Problem)
                    .HasForeignKey(d => d.Category)
                    .HasConstraintName("problem_problemCategoryId_Fkey2");

                entity.HasOne(d => d.Review)
                    .WithMany(p => p.Problem)
                    .HasForeignKey(d => d.ReviewId)
                    .HasConstraintName("problem_ReviewId_Fkey1");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.Problem)
                    .HasForeignKey(d => d.Status)
                    .HasConstraintName("problem_problemStatusId_Fkey3");
            });

            modelBuilder.Entity<ProblemCategory>(entity =>
            {
                entity.ToTable("problem_category");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('problem_category_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<ProblemInvestigation>(entity =>
            {
                entity.ToTable("problem_investigation");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('problem_investigation_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.HasOne(d => d.Investigation)
                    .WithMany(p => p.ProblemInvestigation)
                    .HasForeignKey(d => d.InvestigationId)
                    .HasConstraintName("problemInvestigation_investigationId_FKey2");

                entity.HasOne(d => d.Problem)
                    .WithMany(p => p.ProblemInvestigation)
                    .HasForeignKey(d => d.ProblemId)
                    .HasConstraintName("problemInvestigation_problemId_FKey1");
            });

            modelBuilder.Entity<ProblemStatus>(entity =>
            {
                entity.ToTable("problem_status");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('problem_status_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<Property>(entity =>
            {
                entity.ToTable("property");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('property_id_seq'::regclass)");

                entity.Property(e => e.Address)
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Reservation>(entity =>
            {
                entity.ToTable("reservation");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('reservation_id_seq'::regclass)");

                entity.Property(e => e.ConfirmationNumber)
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.DateCreated)
                    .HasColumnName("Date_Created")
                    .HasColumnType("time");

                entity.Property(e => e.LastUpdated)
                    .HasColumnName("Last_Updated")
                    .HasColumnType("time");

                entity.Property(e => e.MiscDetails)
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Guest)
                    .WithMany(p => p.Reservation)
                    .HasForeignKey(d => d.GuestId)
                    .HasConstraintName("reservation_guestId_FKey1");
            });

            modelBuilder.Entity<Review>(entity =>
            {
                entity.ToTable("review");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.PostedDate).HasColumnType("time");

                entity.Property(e => e.ReferenceNumber)
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.TranslatedDesc)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.TranslatedTitle)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.HasOne(d => d.AssignedToNavigation)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.AssignedTo)
                    .HasConstraintName("review_userId_FKey6");

                entity.HasOne(d => d.Channel)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.ChannelId)
                    .HasConstraintName("review_channelId_FKey3");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.LanguageId)
                    .HasConstraintName("review_languageId_FKey4");

                entity.HasOne(d => d.Property)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.PropertyId)
                    .HasConstraintName("review_propertyId_FKey5");

                entity.HasOne(d => d.Reservation)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.ReservationId)
                    .HasConstraintName("review_reservationId_FKey7");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.Status)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("review_reviewStatusId_FKey1");

                entity.HasOne(d => d.TypeNavigation)
                    .WithMany(p => p.Review)
                    .HasForeignKey(d => d.Type)
                    .HasConstraintName("review_reviewType_FKey2");
            });

            modelBuilder.Entity<ReviewComment>(entity =>
            {
                entity.ToTable("review_comment");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_comment_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Details)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.HasOne(d => d.Review)
                    .WithMany(p => p.ReviewComment)
                    .HasForeignKey(d => d.ReviewId)
                    .HasConstraintName("reviewComment_ReviewId_FKey1");
            });

            modelBuilder.Entity<ReviewResponse>(entity =>
            {
                entity.ToTable("review_response");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_response_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.HasOne(d => d.Review)
                    .WithMany(p => p.ReviewResponse)
                    .HasForeignKey(d => d.ReviewId)
                    .HasConstraintName("reviewResponse_ReviewId_FKey1");
            });

            modelBuilder.Entity<ReviewStatus>(entity =>
            {
                entity.ToTable("review_status");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_status_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<ReviewTranslation>(entity =>
            {
                entity.ToTable("review_translation");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_translation_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.HasOne(d => d.Review)
                    .WithMany(p => p.ReviewTranslation)
                    .HasForeignKey(d => d.ReviewId)
                    .HasConstraintName("reviewTranslation_reviewId_FKey1");

                entity.HasOne(d => d.Translation)
                    .WithMany(p => p.ReviewTranslation)
                    .HasForeignKey(d => d.TranslationId)
                    .HasConstraintName("reviewTranslation_translationId_FKey1");
            });

            modelBuilder.Entity<ReviewType>(entity =>
            {
                entity.ToTable("review_type");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('review_type_id_seq'::regclass)");

                entity.Property(e => e.DateCreated).HasColumnName("Date_Created");

                entity.Property(e => e.Description)
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.LastUpdated).HasColumnName("Last_Updated");

                entity.Property(e => e.Title)
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("role");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_role_id'::regclass)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar")
                    .HasMaxLength(250);

                entity.Property(e => e.Enabled)
                    .IsRequired()
                    .HasColumnName("enabled")
                    .HasColumnType("bit");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<RoleFeaturePermission>(entity =>
            {
                entity.ToTable("role_feature_permission");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.FeaturePermissionId).HasColumnName("feature_permission_id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasColumnType("time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.RoleId)
                    .HasColumnName("role_id")
                    .HasDefaultValueSql("nextval('seq_role_bookmark_permission_id'::regclass)");

                entity.HasOne(d => d.FeaturePermission)
                    .WithMany(p => p.RoleFeaturePermission)
                    .HasForeignKey(d => d.FeaturePermissionId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK2_role_feature_permission");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleFeaturePermission)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK1_role_feature_permission");
            });

            modelBuilder.Entity<Translation>(entity =>
            {
                entity.ToTable("translation");

                entity.Property(e => e.Id).HasDefaultValueSql("nextval('translation_id_seq'::regclass)");

                entity.Property(e => e.DateCreated)
                    .HasColumnName("Date_Created")
                    .HasColumnType("time");

                entity.Property(e => e.LastUpdated)
                    .HasColumnName("Last_Updated")
                    .HasColumnType("time");

                entity.Property(e => e.OriginalText)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.TranslatedText)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.HasOne(d => d.FromLanguage)
                    .WithMany(p => p.TranslationFromLanguage)
                    .HasForeignKey(d => d.FromLanguageId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("translation_FromlanguageId_FKey1");

                entity.HasOne(d => d.ToLanguage)
                    .WithMany(p => p.TranslationToLanguage)
                    .HasForeignKey(d => d.ToLanguageId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("translation_ToLanguageId_FKey1");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("users");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('seq_user_id'::regclass)");

                entity.Property(e => e.Departmentid).HasColumnName("departmentid");

                entity.Property(e => e.EmailId)
                    .IsRequired()
                    .HasColumnName("email_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.LoginId)
                    .IsRequired()
                    .HasColumnName("login_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.Departmentid)
                    .HasConstraintName("fk_user_department");
            });

            modelBuilder.Entity<UsersRole>(entity =>
            {
                entity.ToTable("users_role");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.LastUpdate)
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UsersRole)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_users_role");
            });

            modelBuilder.HasSequence("channel_id_seq").StartsAt(11);

            modelBuilder.HasSequence("department_id_seq").StartsAt(10);

            modelBuilder.HasSequence("guest_id_seq").StartsAt(11);

            modelBuilder.HasSequence("investigation_id_seq").StartsAt(11);

            modelBuilder.HasSequence("investigation_status_id_seq").StartsAt(11);

            modelBuilder.HasSequence("language_id_seq").StartsAt(11);

            modelBuilder.HasSequence("problem_category_id_seq").StartsAt(11);

            modelBuilder.HasSequence("problem_id_seq").StartsAt(11);

            modelBuilder.HasSequence("problem_investigation_id_seq").StartsAt(11);

            modelBuilder.HasSequence("problem_status_id_seq").StartsAt(11);

            modelBuilder.HasSequence("property_id_seq").StartsAt(11);

            modelBuilder.HasSequence("reservation_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_comment_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_response_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_status_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_translation_id_seq").StartsAt(11);

            modelBuilder.HasSequence("review_type_id_seq").StartsAt(11);

            modelBuilder.HasSequence("seq_bookmark_id").HasMin(0);

            modelBuilder.HasSequence("seq_bookmark_permission_id");

            modelBuilder.HasSequence("seq_permission_type_id");

            modelBuilder.HasSequence("seq_role_bookmark_permission_id");

            modelBuilder.HasSequence("seq_role_id");

            modelBuilder.HasSequence("seq_user_id");

            modelBuilder.HasSequence("translation_id_seq").StartsAt(11);
        }
    }
}