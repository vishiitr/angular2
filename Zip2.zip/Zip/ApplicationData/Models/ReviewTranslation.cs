﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class ReviewTranslation
    {
        public long Id { get; set; }
        public long? ReviewId { get; set; }
        public long? TranslationId { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual Review Review { get; set; }
        public virtual Translation Translation { get; set; }
    }
}
