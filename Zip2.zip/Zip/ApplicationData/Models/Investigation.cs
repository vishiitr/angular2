﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Investigation
    {
        public Investigation()
        {
            ProblemInvestigation = new HashSet<ProblemInvestigation>();
        }

        public long Id { get; set; }
        public long? AssignedPersonId { get; set; }
        public long? ProblemId { get; set; }
        public int? Status { get; set; }
        public string Reason { get; set; }
        public string Resolution { get; set; }
        public string SupervisorFeedback { get; set; }
        public long? SupervisorId { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual ICollection<ProblemInvestigation> ProblemInvestigation { get; set; }
        public virtual Users AssignedPerson { get; set; }
        public virtual Problem Problem { get; set; }
        public virtual InvestigationStatus StatusNavigation { get; set; }
        public virtual Users Supervisor { get; set; }
    }
}
