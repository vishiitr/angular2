﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class FeaturePermission
    {
        public FeaturePermission()
        {
            RoleFeaturePermission = new HashSet<RoleFeaturePermission>();
        }

        public int FeatureId { get; set; }
        public int PermissionId { get; set; }
        public TimeSpan LastUpdate { get; set; }
        public int Id { get; set; }

        public virtual ICollection<RoleFeaturePermission> RoleFeaturePermission { get; set; }
        public virtual Feature Feature { get; set; }
        public virtual PermissionType Permission { get; set; }
    }
}
