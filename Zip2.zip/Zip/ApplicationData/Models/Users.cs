﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Users
    {
        public Users()
        {
            InvestigationAssignedPerson = new HashSet<Investigation>();
            InvestigationSupervisor = new HashSet<Investigation>();
            Review = new HashSet<Review>();
            UsersRole = new HashSet<UsersRole>();
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public string LoginId { get; set; }
        public string Password { get; set; }
        public DateTime LastUpdate { get; set; }
        public string EmailId { get; set; }
        public int? Departmentid { get; set; }

        public virtual ICollection<Investigation> InvestigationAssignedPerson { get; set; }
        public virtual ICollection<Investigation> InvestigationSupervisor { get; set; }
        public virtual ICollection<Review> Review { get; set; }
        public virtual ICollection<UsersRole> UsersRole { get; set; }
        public virtual Department Department { get; set; }
    }
}
