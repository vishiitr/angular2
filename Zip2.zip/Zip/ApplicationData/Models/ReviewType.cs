﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class ReviewType
    {
        public ReviewType()
        {
            Review = new HashSet<Review>();
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual ICollection<Review> Review { get; set; }
    }
}
