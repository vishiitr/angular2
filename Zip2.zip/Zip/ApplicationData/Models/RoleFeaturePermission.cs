﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class RoleFeaturePermission
    {
        public int RoleId { get; set; }
        public int FeaturePermissionId { get; set; }
        public TimeSpan? LastUpdate { get; set; }
        public int Id { get; set; }

        public virtual FeaturePermission FeaturePermission { get; set; }
        public virtual Role Role { get; set; }
    }
}
