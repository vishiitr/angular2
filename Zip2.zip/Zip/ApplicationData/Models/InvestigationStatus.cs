﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class InvestigationStatus
    {
        public InvestigationStatus()
        {
            Investigation = new HashSet<Investigation>();
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? IsEnabled { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }

        public virtual ICollection<Investigation> Investigation { get; set; }
    }
}
