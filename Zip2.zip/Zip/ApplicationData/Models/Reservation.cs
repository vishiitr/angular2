﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Reservation
    {
        public Reservation()
        {
            Review = new HashSet<Review>();
        }

        public long Id { get; set; }
        public string ConfirmationNumber { get; set; }
        public string MiscDetails { get; set; }
        public long? GuestId { get; set; }
        public TimeSpan LastUpdated { get; set; }
        public TimeSpan DateCreated { get; set; }

        public virtual ICollection<Review> Review { get; set; }
        public virtual Guest Guest { get; set; }
    }
}
