﻿using System;
using System.Collections.Generic;

namespace ApplicationData.Models
{
    public partial class Translation
    {
        public Translation()
        {
            ReviewTranslation = new HashSet<ReviewTranslation>();
        }

        public long Id { get; set; }
        public int FromLanguageId { get; set; }
        public int ToLanguageId { get; set; }
        public string OriginalText { get; set; }
        public string TranslatedText { get; set; }
        public int? IsDone { get; set; }
        public TimeSpan LastUpdated { get; set; }
        public TimeSpan DateCreated { get; set; }

        public virtual ICollection<ReviewTranslation> ReviewTranslation { get; set; }
        public virtual Language FromLanguage { get; set; }
        public virtual Language ToLanguage { get; set; }
    }
}
