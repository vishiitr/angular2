﻿using ApplicationData.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace ApplicationData
{
    /// <summary>
    /// Class Repository Base.
    /// </summary>
    /// <typeparam name="TEntity">The type of the t entity.</typeparam>
    public class RepositoryBase<TEntity> :  IDisposable where TEntity : class
    {
        protected RMSContext dbContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryBase{TEntity}"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public RepositoryBase()
        {
            dbContext = new RMSContext();
        }

        /// <summary>
        /// Inserts the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>TEntity.</returns>
        public virtual TEntity Insert(TEntity entity)
        {
            var result = dbContext.Set<TEntity>().Add(entity);
            SaveChanges();
            return result.Entity;
        }

        /// <summary>
        /// Updates the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>TEntity.</returns>
        public virtual TEntity Update(TEntity entity)
        {
            dbContext.Entry(entity).State = EntityState.Modified;
            SaveChanges();
            return entity;
        }

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public virtual void Delete(TEntity entity)
        {
            dbContext.Set<TEntity>().Remove(entity);
            //SaveChanges();
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <param name="where">The where.</param>
        /// <returns>IEnumerable&lt;TEntity&gt;.</returns>
        public IQueryable<TEntity> GetAll(Expression<Func<TEntity, bool>> where = null)
        {
            return null != where ? dbContext.Set<TEntity>().Where(where) : dbContext.Set<TEntity>();
        }

        /// <summary>
        /// Gets the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>TEntity.</returns>
        public TEntity Get(object id)
        {
            return dbContext.Set<TEntity>().Find(id);
        }

        /// <summary>
        /// Saves the changes.
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public virtual bool SaveChanges()
        {
            return 0 < dbContext.SaveChanges();
        }

        /// <summary>
        /// Releases all resources used by the Entities
        /// </summary>
        public void Dispose()
        {
            if (null != dbContext)
            {
                dbContext.Dispose();
            }
        }
    }
}
