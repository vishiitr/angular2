﻿using ApplicationData;
using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Business
{
    public class UsersBDC : BDCBase, IUsersBDC
    {
        /// <summary>
        /// The ClientApp Repository
        /// </summary>
        private IUsersRepository userRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientAppBDC"/> class.
        /// </summary>
        /// <param name="accountRepository">The ClientApp repository.</param>
        public UsersBDC()
        {
            this.userRepository = new UsersRepository();
        }

        public IList<Users> GetUsers()
        {
            return userRepository.GetAll().ToList();
        }

        public Users GetUser(int id)
        {
            return userRepository.GetAll().Include(t => t.UsersRole).First(f => f.Id == id);
        }

        public void EditUser(UsersDto user)
        {
            var userFromDb = userRepository.GetAll().Include(t => t.UsersRole).First(f => f.Id == user.Id);
            userFromDb.LoginId = user.LoginId;
            userFromDb.Name = user.Name;
            userFromDb.EmailId = user.EmailId;
            userFromDb.Departmentid = user.DepartmentId;
            if (userFromDb.UsersRole.FirstOrDefault() != null)
            {
                var userRole = userFromDb.UsersRole.First();
                userRole.RoleId = user.RoleId;
            }
            else
            {
                userFromDb.UsersRole.Add(new UsersRole { RoleId = user.RoleId, UserId = user.Id });
            }
            userRepository.Update(userFromDb);
            userRepository.SaveChanges();
        }

        public void DeleteUser(int id)
        {
            var user = userRepository.Get(id);
            userRepository.Delete(user);
            userRepository.SaveChanges();
        }

        public Users AddUser(UsersDto user)
        {
            var userForDb = new Users();
            userForDb.LoginId = user.LoginId;
            userForDb.Name = user.Name;
            userForDb.EmailId = user.EmailId;
            userForDb.Password = string.Empty;
            userForDb.Departmentid = user.DepartmentId;
            userForDb.UsersRole.Add(new UsersRole { RoleId = user.RoleId });

            userRepository.Insert(userForDb);
            userRepository.SaveChanges();

            return userForDb;
        }
    }
}
