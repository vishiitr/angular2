﻿using ApplicationData;
using ApplicationData.Models;
using System.Collections.Generic;
using System.Linq;
using Shared;
using System;
using Microsoft.EntityFrameworkCore;
using NpgsqlTypes;
namespace Business
{
    public class ReviewBDC : BDCBase, IReviewBDC
    {
        private IReviewRepository _reviewRepository;

        public ReviewBDC()
        {
            this._reviewRepository = new ReviewRepository();
        }

        public Review AddReview(ReviewDto review)
        {
            var reviewForDb = new Review();
            reviewForDb.AssignedTo = review.AssignedTo;

            this._reviewRepository.Insert(reviewForDb);
            this._reviewRepository.SaveChanges();
            return reviewForDb;
        }

        public void DeleteReview(int id)
        {
            var reviewFromDb = this._reviewRepository.Get(id);
            this._reviewRepository.Delete(reviewFromDb);
            this._reviewRepository.SaveChanges();
        }

        public void EditReview(ReviewDto review)
        {
            var reviewFromDb = this._reviewRepository.Get(review.Id);
            reviewFromDb.Language.Id = review.LanguageId.Value;
            this._reviewRepository.Update(reviewFromDb);
            this._reviewRepository.SaveChanges();
        }

        public Review GetReview(int id)
        {
            var reviewFromDb = this._reviewRepository.Get(id);
            return reviewFromDb;
        }

        public IList<Review> GetReviews()
        {
            var reviewsFromDb = this._reviewRepository.GetAll().Include("StatusNavigation").ToList<Review>();
            return reviewsFromDb;
        }
    }
}
