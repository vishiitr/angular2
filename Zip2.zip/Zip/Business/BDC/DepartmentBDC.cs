﻿using ApplicationData;
using ApplicationData.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Shared;

namespace Business.BDC
{
    public class DepartmentBDC : BDCBase, IDepartmentBDC
    {
        private IDepartmentRepository _departmentRepository;

        public DepartmentBDC()
        {
            this._departmentRepository = new DepartmentRepository();
        }

        public IList<Department> GetDepartments()
        {
            return _departmentRepository.GetAll().ToList();
        }

        public Department AddDepartment(DepartmentDto department)
        {
            var roleForDb = new Department();
            roleForDb.Id = department.Id;
            roleForDb.Name = department.Name;
            roleForDb.Description = department.Description;
            roleForDb.Enabled = new System.Collections.BitArray(new bool[] { true });
            var updatedDepartment = _departmentRepository.Insert(roleForDb);
            _departmentRepository.SaveChanges();

            return updatedDepartment;
        }

        public void DeleteDepartment(int id)
        {
            var departmentFromDb = _departmentRepository.Get(id);
            _departmentRepository.Delete(departmentFromDb);
            _departmentRepository.SaveChanges();
        }

        public void EditDepartment(DepartmentDto department)
        {
            var departmentFromDb = _departmentRepository.Get(department.Id);
            departmentFromDb.Id = department.Id;
            departmentFromDb.Name = department.Name;
            departmentFromDb.Description = department.Description;
            _departmentRepository.Update(departmentFromDb);
            _departmentRepository.SaveChanges();
        }
    }
}
