﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public struct VoidResult
    {
        public static readonly VoidResult Default = new VoidResult();
    }
}
