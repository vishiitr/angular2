﻿using System;

namespace Business
{
    /// <summary>
    /// Represents the Validation Error Item
    /// </summary>
    public class ValidationErrorItem
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the field.
        /// </summary>
        /// <value>The field.</value>
        public string Field { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationErrorItem"/> class.
        /// </summary>
        public ValidationErrorItem()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationErrorItem"/> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        /// <param name="field">The field.</param>
        public ValidationErrorItem(string code, string message, string field)
        {
            this.Code = code;
            this.Message = message;
            this.Field = field;
        }
    }
}