﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    /// <summary>
    /// Enum ResultType
    /// </summary>
    public enum ResultType
    {
        /// <summary>
        /// The success
        /// </summary>
        Success = 0,
        /// <summary>
        /// The failure
        /// </summary>
        Failure = 1,
        /// <summary>
        /// The error
        /// </summary>
        Error = 2,
    }
}
