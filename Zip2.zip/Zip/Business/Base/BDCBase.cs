﻿using System;
namespace Business
{
    /// <summary>
    /// Represents the BDCBase
    /// </summary>
    public abstract class BDCBase : IBDC
    {
        //protected ILogger _logger;
        //public BDCBase(ILogger logger)
        //{
        //    _logger = logger;
        //}
    }
}
