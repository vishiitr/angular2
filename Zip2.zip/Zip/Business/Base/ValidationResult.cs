﻿using System.Collections.Generic;

namespace Business
{
    /// <summary>
    /// Represents the ValidationError
    /// </summary>
    public class ValidationError
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the validation error items.
        /// </summary>
        /// <value>The validation error items.</value>
        public IList<ValidationErrorItem> ValidationErrorItems { get; set; }
    }
}
