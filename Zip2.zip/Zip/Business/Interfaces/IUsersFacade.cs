﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IUsersFacade
    {
        Result<IList<UsersDto>> GetUsers();

        UsersDto GetUser(int id);

        void EditUser(UsersDto user);

        void DeleteUser(int id);

        Result<UsersDto> AddUser(UsersDto userdto);        
    }
}