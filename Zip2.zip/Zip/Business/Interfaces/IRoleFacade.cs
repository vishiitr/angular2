﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;

namespace Business
{
    public interface IRoleFacade
    {
        Result<IList<RoleDto>> GetRoles();

        Result<RoleDto> GetRole(int id);

        void EditRole(RoleDto user);

        void DeleteRole(int id);

        Result<RoleDto> AddRole(RoleDto userdto);

        Result<IList<FeatureDto>> GetFeatures();

        Result<bool> UpdateRoleFeaturePermission(RoleFeaturePermissionDto roleFeaturePermissionDto);
    }
}