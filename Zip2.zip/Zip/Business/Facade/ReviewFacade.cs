﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Business
{
    public class ReviewFacade : FacadeBase, IReviewFacade
    {
        private IReviewBDC _reviewBDC;

        public ReviewFacade()
        {
            this._reviewBDC = new ReviewBDC();
        }

        public Result<ReviewDto> AddReview(ReviewDto reviewToAdd)
        {
            Result<ReviewDto> result = this.Invoke<ReviewDto>
                   (
                       () =>
                       {
                           var review = _reviewBDC.AddReview(reviewToAdd);
                           var reviewDto = new ReviewDto
                           {
                               Id = review.Id,
                               Description = review.Description
                           };
                           return Result<ReviewDto>.CreateSuccessResult(reviewDto);
                       }

                   );
            return result;
        }

        public void DeleteReview(int id)
        {
            this._reviewBDC.DeleteReview(id);
        }

        public void EditReview(ReviewDto review)
        {
            this._reviewBDC.EditReview(review);
        }

        public Result<ReviewDto> GetReview(int id)
        {
            Result<ReviewDto> result = this.Invoke<ReviewDto>
                   (
                       () =>
                       {
                           var review = this._reviewBDC.GetReview(id);
                           var reviewDto = new ReviewDto
                           {
                               Id = review.Id,
                               //FeaturePermissions = new Dictionary<string, List<FeaturePermissionDto>>()
                           };
                           //foreach (var item in role.RoleFeaturePermission)
                           //{
                           //    if (!roleDto.FeaturePermissions.ContainsKey(item.FeaturePermission.Feature.Title))
                           //    {
                           //        roleDto.FeaturePermissions.Add(item.FeaturePermission.Feature.Title, new List<FeaturePermissionDto>() {
                           //            new FeaturePermissionDto
                           //                {
                           //                    FeaturePermissionId = item.FeaturePermissionId,
                           //                    PermissionName = item.FeaturePermission.Permission.Name
                           //                }});

                           //    }
                           //    else
                           //    {
                           //        roleDto.FeaturePermissions[item.FeaturePermission.Feature.Title].Add(new FeaturePermissionDto
                           //        {
                           //            FeaturePermissionId = item.FeaturePermissionId,
                           //            PermissionName = item.FeaturePermission.Permission.Name
                           //        });
                           //    }
                           //}
                           return Result<ReviewDto>.CreateSuccessResult(reviewDto);
                       }

                   );
            return result;


        }

        //public Result<IList<ReviewDto>> GetReview()
        //{
        //    Result<IList<ReviewDto>> result = this.Invoke<IList<ReviewDto>>
        //           (
        //               () =>
        //               {
        //                   var reviews = this._reviewBDC.GetReviews();
        //                   var reviewDtos = reviews.Select(t => new ReviewDto
        //                   {
        //                       Id = t.Id,
        //                       Description = t.Description
        //                   }).ToList();
        //                   return Result<IList<ReviewDto>>.CreateSuccessResult(reviewDtos);
        //               }

        //           );
        //    return result;
        //}

        public Result<IList<ReviewDto>> GetReviews()
        {
            Result<IList<ReviewDto>> result = this.Invoke<IList<ReviewDto>>
                   (
                       () =>
                       {
                           var reviews = this._reviewBDC.GetReviews();
                           var reviewDtos = reviews.Select(t => new ReviewDto
                           {
                               Id = t.Id,
                               Description = t.Description,
                               Status = new ReviewStatusDto { Id = t.StatusNavigation.Id, Title = t.StatusNavigation.Title },
                               StatusId = t.StatusNavigation.Id,
                               Title = t.Title,
                               Score = t.Score,
                               PropertyId = t.PropertyId,
                               ReferenceNumber = t.ReferenceNumber,
                               Rating = t.Rating
                           }).ToList();
                           return Result<IList<ReviewDto>>.CreateSuccessResult(reviewDtos);
                       }
                   );
            return result;
        }
    }
}