﻿using ApplicationData.Models;
using Shared;
using System.Collections.Generic;
using System.Linq;

namespace Business
{
    /// <summary>
    /// Represents the ClientApp Facade
    /// </summary>
    public class UsersFacade : FacadeBase, IUsersFacade
    {
        private IUsersBDC userBDC;

        public UsersFacade()
        {
            this.userBDC = new UsersBDC();
        }

        public Result<IList<UsersDto>> GetUsers()
        {
            Result<IList<UsersDto>> result = this.Invoke<IList<UsersDto>>
                   (
                       () =>
                       {
                           var users = userBDC.GetUsers();
                           var usersDto = users.Select(t => new UsersDto
                           {
                               EmailId = t.EmailId,
                               Id = t.Id,
                               LoginId = t.LoginId,
                               Name = t.Name,
                               DepartmentId = t.Departmentid.HasValue ? t.Departmentid.Value : 0
                           }).ToList();
                           return Result<IList<UsersDto>>.CreateSuccessResult(usersDto);
                       }

                   );
            return result;
        }

        public UsersDto GetUser(int id)
        {
            var user = userBDC.GetUser(id);
            var userDto = new UsersDto
            {
                EmailId = user.EmailId,
                Id = user.Id,
                LoginId = user.LoginId,
                Name = user.Name,
                DepartmentId = user.Departmentid.HasValue ? user.Departmentid.Value : 0
            };
            if (user.UsersRole.FirstOrDefault() != null)
                userDto.RoleId = user.UsersRole.First().RoleId;
            if (user.Department != null)
                userDto.DepartmentId = user.Department.Id;
            return userDto;
        }

        public void EditUser(UsersDto user)
        {
            userBDC.EditUser(user);
        }

        public void DeleteUser(int id)
        {
            userBDC.DeleteUser(id);
        }

        public Result<UsersDto> AddUser(UsersDto userdto)
        {
            Result<UsersDto> result = this.Invoke<UsersDto>
                   (
                       () =>
                       {
                           var user = userBDC.AddUser(userdto);
                           var usersDto = new UsersDto
                           {
                               EmailId = user.EmailId,
                               Id = user.Id,
                               LoginId = user.LoginId,
                               Name = user.Name
                           };
                           return Result<UsersDto>.CreateSuccessResult(usersDto);
                       }

                   );
            return result;
        }
    }
}