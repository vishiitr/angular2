﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Collections.Generic;
using System;
using RMS.Models;
using ApplicationData;
using ApplicationData.Models;
using Business;
using Shared;

namespace RMS.Controllers
{
  [Route("api/[controller]/[action]")]
  public class DepartmentController : ApiController
  {
    IDepartmentFacade _departmentFacade;

    public DepartmentController(IDepartmentFacade departmentFacade)
    {
      _departmentFacade = departmentFacade;
    }

    [HttpGet]
    [ActionName("GetDepartments")]
    public Result<IList<DepartmentDto>> GetDepartments()
    {
      return _departmentFacade.GetDepartments();
    }


    [HttpPut]
    [ActionName("EditDepartment")]
    public bool EditDepartment([FromBody]DepartmentDto department)
    {
      try
      {
        _departmentFacade.EditDepartment(department);
        return true;
      }
      catch(Exception ex)
      {
        return false;
      }
    }

    [HttpDelete]
    [ActionName("DeleteDepartment")]
    public bool DeleteDepartment(int id)
    {
      try
      {
        _departmentFacade.DeleteDepartment(id);
        return true;
      }
      catch(Exception ex)
      {
        return false;
      }
    }

    [HttpPost]
    [ActionName("AddDepartment")]
    public Result<DepartmentDto> AddDepartment([FromBody]DepartmentDto department)
    {
      return _departmentFacade.AddDepartment(department);
    }
  }
}
