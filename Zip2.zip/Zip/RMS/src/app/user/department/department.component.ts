﻿import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DepartmentService } from "./department.service";
declare let $: any;

@Component({
    moduleId: module.id,
    selector: 'regular-table-cmp',
    templateUrl: 'department.component.html',
    encapsulation: ViewEncapsulation.None,
    styles: [`#roleTable .form-group
                {margin:0px;}
.close .material-icons{font-size:25px!important;color:#ed457d;font-weight:bold}
input:read-only{
background-image:none!important;
}
#roleTable .form-group{
padding-bottom:0;
margin:0!important;
}
    `]
})

export class DepartmentComponent implements OnInit {
    public departments;
    public selectedRoleId;
    public isNewDepartment = false;
    public newDepartment = { "Name": "", "Description": "" };
    public departmentListBackup = [];
    constructor(private departmentService: DepartmentService) { }

    ngOnInit() {
        this.departments = {
            headerRow: ['Id', 'Name', 'Description', 'Action'],
            dataRows: []
        }
        this.departmentService.getDepartments().subscribe(resp => {
            this.departments.dataRows = resp.Data;
            this.departments.dataRows.forEach(function (item) {
                item.isEditable = false;
            });
        });
    }

    addDepartment() {
        this.isNewDepartment = true;
    }

    cancelNewDepartment() {
        this.isNewDepartment = false;
        this.newDepartment = { "Name": "", "Description": "" };
    }

    saveDepartment() {
        var self = this;
        this.departmentService.addDepartment(this.newDepartment).subscribe(t => {
            self.isNewDepartment = false;
            self.newDepartment = { "Name": "", "Description": "" };
            this.departments.dataRows.push(t);
        });
    }

    editDepartment(departmentRow) {
        var self = this;
        if (departmentRow.isEditable) {
            this.departmentService.editDepartment(departmentRow).subscribe(t => {
                departmentRow.isEditable = false;
                $.each(self.departmentListBackup, function (i) {
                    if (self.departmentListBackup[i].Id === departmentRow.Id) {
                        var obj = self.departmentListBackup.splice(i, 1);
                    }
                });
            });
        }
        else {
            var backupRole = JSON.parse(JSON.stringify(departmentRow));
            var isRoleExists = this.departmentListBackup.find(t => t.Id == departmentRow.Id);
            if (!isRoleExists)
                this.departmentListBackup.push(backupRole);
            departmentRow.isEditable = true;
        }
    }

    cancelOrDeleteDeparment(departmentRow) {
        var self = this;
        if (departmentRow.isEditable) {
            $.each(self.departmentListBackup, function (i) {
                if (self.departmentListBackup[i].Id === departmentRow.Id) {
                    var obj = self.departmentListBackup.splice(i, 1);
                    departmentRow.isEditable = false;
                    departmentRow.Name = obj[0].Name;
                    departmentRow.Description = obj[0].Description;
                    return false;
                }
            })
        }
        else {
            this.departmentService.deleteDepartment(departmentRow.Id).subscribe(t => {
                if (t)
                    self.departments.dataRows = self.departments.dataRows.filter(obj => obj.Id !== departmentRow.Id);
                else
                    alert("Department can not be deleted, because it assigned.");
            });
        }
    }

}
