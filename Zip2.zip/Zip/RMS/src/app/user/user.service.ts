﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { myResponse } from '../shared/Response';

import { User } from './user';

@Injectable()
export class UserService {
    constructor(private http: HttpClient) {
    }

    getUsers() {
        return this.http.get<myResponse<User[]>>('/api/user/GetUsers');
    }

    getUser(id: number) {
        return this.http.get<myResponse<User>>('/api/user/GetUser?id=' + id);
    }

    addUser(user: User) {
        return this.http.post('/api/user/CreateUser', user);
    }

    editUser(user: User) {
        return this.http.put('/api/user/EditUser?id=' + user.Id, user);
    }

    deleteUser(id: number) {
        return this.http.delete('/api/user/DeleteUser?id=' + id);
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
}