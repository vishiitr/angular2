﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { myResponse } from '../shared/Response';
import { role } from './Role';
import { feature } from './Features';


@Injectable()
export class RoleService {

    constructor(private http: HttpClient) { }

    getRoles() {
        return this.http.get<myResponse<role[]>>('/api/Role/GetRoles');
    }

    getFeatures() {
        return this.http.get<myResponse<feature[]>>('/api/Role/GetFeatures');
    }

    getRole(id: number) {
        return this.http.get<myResponse<role>>('/api/Role/GetRole?id=' + id);
    }

    savePermission(permssions: any) {
        return this.http.post('/api/Role/UpdatePermissions', permssions);
    }

    saveRole(role: any) {
        return this.http.post('/api/Role/AddRole', role);
    }

    editRole(role: any) {
        return this.http.put('/api/Role/EditRole', role);
    }

    deleteRole(roleId: any) {
        return this.http.delete('/api/Role/DeleteRole?id=' + roleId);
    }
}
