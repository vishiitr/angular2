﻿export class feature {
    Id: number;
    Title: string;
    Description: string;
    LastUpdate: "0001-01-01T00:00:00";
}