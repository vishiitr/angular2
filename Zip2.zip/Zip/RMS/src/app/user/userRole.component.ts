﻿import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { RoleService } from "./role.service";
import { role } from './Role';
import { feature } from './Features';

// import { TableData } from '../md/md-table/md-table.component';
declare let $: any;

@Component({
    moduleId: module.id,
    selector: 'regular-table-cmp',
    templateUrl: 'userRole.component.html',
    encapsulation: ViewEncapsulation.None,
    styles: [`#roleTable .form-group
                {margin:0px;}
.close .material-icons{font-size:25px!important;color:#ed457d;font-weight:bold}
input:read-only{
background-image:none!important;
}
#roleTable .form-group{
padding-bottom:0;
margin:0!important;
}
    `]
})

export class UserRoleComponent implements OnInit {
    public roleDetailTable;
    public roles;
    public selectedRoleId;
    public isNewRole = false;
    public newRole = { "Name": "", "Description": "" };
    public roleListBackup = [];
    constructor(private roleService: RoleService) { }

    ngOnInit() {
        this.roles = {
            headerRow: ['Id', 'Name', 'Description', 'Action'],
            dataRows: []
        }
        this.roleService.getRoles().subscribe(resp => {
            this.roles.dataRows = resp.Data;
            this.roles.dataRows.forEach(function (item) {
                item.isEditable = false;
            });
        });
        this.roleDetailTable = {
            headerRow: ['Name', 'Read', 'Update', 'Create', 'Delete'],
            dataRows: []
        };
    }

    addRole() {
        this.isNewRole = true;
        //$("#roleTable").append(`<tr id="newRole">
        //            <td class="text-center">N/A</td>
        //            <td><div class="form-group label-floating is-empty"><label class="control-label"></label><input name="Name" type="text" class="form-control"></div></td>
        //            <td><div class="form-group label-floating is-empty"><label class="control-label"></label><input name="Description" type="text" class="form-control"></div></td>
        //            <td class="td-actions text-right">
        //              <button type="button" rel="tooltip" class="btn btn-info" (click)="viewRolePermission(row.Id)">
        //                <i class="material-icons">save</i>
        //              </button>
        //              <button type="button" rel="tooltip" class="btn btn-success" (click)="cancelNewRole()">
        //                <i class="material-icons">close</i>
        //              </button>
        //            </td>
        //          </tr>`)
    }

    cancelNewRole() {
        this.isNewRole = false;
        this.newRole = { "Name": "", "Description": "" };
    }

    saveRole() {
        var self = this;
        this.roleService.saveRole(this.newRole).subscribe(t => {
            self.isNewRole = false;
            self.newRole = { "Name": "", "Description": "" };
            this.roles.dataRows.push(t);
        });
    }

    savePermissions() {
        this.roleService.savePermission({ "RoleId": this.selectedRoleId, "FeaturePermissions": this.roleDetailTable.dataRows }).subscribe();
        console.log(this.roleDetailTable.dataRows);
    }
    viewRolePermission(roleId) {
        this.selectedRoleId = roleId;
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#roleModal').modal('show');
        this.roleDetailTable.dataRows = [];
        this.roleService.getRole(roleId).subscribe(respRole => {
            this.roleService.getFeatures().subscribe(respFeatures => {
                let role: role = respRole.Data;
                let features: feature[] = respFeatures.Data;
                //var features = Object.keys(role.Data.FeaturePermissions);
                for (var i = 0; i < features.length; i++) {
                    var permissionArray: any = {};
                    var featureName = features[i].Title;
                    permissionArray.featureName = featureName;
                    if (role.FeaturePermissions[featureName] && role.FeaturePermissions[featureName].find(o => o.PermissionName.toLowerCase() == "read"))
                        permissionArray.readPermission = true;
                    else
                        permissionArray.readPermission = false;

                    if (role.FeaturePermissions[featureName] && role.FeaturePermissions[featureName].find(o => o.PermissionName.toLowerCase() == "update"))
                        permissionArray.updatePermission = true;
                    else
                        permissionArray.updatePermission = false;

                    if (role.FeaturePermissions[featureName] && role.FeaturePermissions[featureName].find(o => o.PermissionName.toLowerCase() == "create"))
                        permissionArray.createPermissionName = true;
                    else
                        permissionArray.createPermissionName = false;

                    if (role.FeaturePermissions[featureName] && role.FeaturePermissions[featureName].find(o => o.PermissionName.toLowerCase() == "delete"))
                        permissionArray.deletePermissionName = true;
                    else
                        permissionArray.deletePermissionName = false;

                    this.roleDetailTable.dataRows.push(permissionArray);
                }
                var abc = this.roleDetailTable.dataRows;
                console.log(this.roleDetailTable.dataRows);
            });
        });
    }

    editRole(roleRow) {
        if (roleRow.isEditable) {
            this.roleService.editRole(roleRow).subscribe(t => roleRow.isEditable = false);
        }
        else {
            var backupRole = JSON.parse(JSON.stringify(roleRow));
            var isRoleExists = this.roleListBackup.find(t => t.Id == roleRow.Id);
            if (!isRoleExists)
                this.roleListBackup.push(backupRole);
            roleRow.isEditable = true;
        }
    }

    cancelOrDeleteRole(roleRow) {
        var self = this;
        if (roleRow.isEditable) {
            $.each(self.roleListBackup, function (i) {
                if (self.roleListBackup[i].Id === roleRow.Id) {
                    var obj = self.roleListBackup.splice(i, 1);
                    roleRow.isEditable = false;
                    roleRow.Name = obj[0].Name;
                    roleRow.Description = obj[0].Description;
                    return false;
                }
            })
        }
        else {
            this.roleService.deleteRole(roleRow.Id).subscribe(t => {
                self.roles.dataRows = self.roles.dataRows.filter(obj => obj.Id !== roleRow.Id);
            });
        }
    }

}
