﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { ReviewComponent } from './review.component';

@NgModule({
    imports: [RouterModule, FormsModule, CommonModule],
    declarations: [ReviewComponent],
    exports: [ReviewComponent],
})
export class ReviewModule {

}
