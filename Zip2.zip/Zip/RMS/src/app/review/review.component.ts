﻿import { Component, OnInit } from '@angular/core';
import { ReviewService } from "./review.service";
import { Review } from "./review";

declare let $: any;
@Component({
    selector: 'app-review',
    templateUrl: './review.component.html',
    styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
    public tableData1;
    public review = new Review();
    public reviews: Review[];

    constructor(private reviewService: ReviewService) { }

    ngOnInit() {
        this.tableData1 = {
            headerRow: ['Title', 'Description', 'Translated Title', 'Status', 'Property Id', 'Reservation Id', 'Rating'],
        };
        this.reviewService.getReviews().subscribe(resp => { this.tableData1.reviews = resp.Data; });
    }
    viewUser(id) {
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#myModal2').modal('show');

        this.reviewService.getReview(id).subscribe(resp => { this.review = resp.Data; console.log(this.review); });
    }
    save() {
        var self = this;
        console.log(this.review.Id)

        if (!this.review.Id) {
            this.review.Id = 0;
            this.reviewService.addReview(this.review).subscribe(res => {
                console.log(res)
                self.tableData1.reviews.push(res);
                $('#myModal2').modal('hide');
            });
        }
        else {
            this.reviewService.editReview(this.review).subscribe(res => {
                self.tableData1.users.find((o, i) => {
                    if (o.Id === this.review.Id) {
                        self.tableData1.users[i] = this.review;
                        return true; // stop searching
                    }
                });
                $('#myModal2').modal('hide');
            });
        }
    }

    deleteUser(id) {
        var self = this;
        this.reviewService.deleteReview(id).subscribe(res => {
            self.tableData1.users = self.tableData1.users.filter(obj => obj.Id !== id);
        }
        );
    }

    addReview() {
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#myModal2').modal('show');
        this.review = new Review();
    }
}
