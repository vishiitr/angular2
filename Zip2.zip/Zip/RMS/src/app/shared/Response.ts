﻿export class myResponse<T> {
    Data: T;
    ResultType: any;
    FailureType: any;
    Exception: any;
    ValidationError: any;
    Code: any;
    Message: any;
    Extrainformation: any;
}