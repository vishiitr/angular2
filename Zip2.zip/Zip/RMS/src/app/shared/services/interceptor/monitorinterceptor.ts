﻿import {Injectable} from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpResponse, HttpResponseBase } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { RootContextService} from '../config/root-context.service';
import 'rxjs/add/operator/do';
import { HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class MonitorInterceptor implements HttpInterceptor {
    constructor(private root: RootContextService) { }

    intercept(req: HttpRequest < any >, next: HttpHandler):Observable<HttpEvent<any>> {
        debugger;
        this.root.increaseRequestCount();
        return next
            .handle(req)
            .do(event => {
                if (event instanceof HttpResponse &&
                    event.ok) {
                    this.root.decreaseRequestCount();
                }
            }, (err: HttpErrorResponse) => {
                if (err && !err.ok) {
                    this.root.decreaseRequestCount();
                }
            });
    }
}
