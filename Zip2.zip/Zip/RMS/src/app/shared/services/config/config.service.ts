﻿import { Injectable } from '@angular/core';

@Injectable()
export class ConfigService {
    public ApiUrl: string;
    constructor() {
        this.ApiUrl = 'http://localhost:4200';
    }
}