﻿import {Injectable} from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class RootContextService {
    public maincontext = new Subject<boolean>();
    private requestCount: number;
    constructor() {
        this.requestCount = 0;
    }
    increaseRequestCount(): void {
        debugger;
        this.requestCount = this.requestCount + 1;
        if (this.requestCount > 0) {
            this.maincontext.next(true);
        }
    }

    decreaseRequestCount(): void {
        debugger;
        this.requestCount = this.requestCount - 1;
        if (this.requestCount === 0) {
            this.maincontext.next(false);
        }
    }
}