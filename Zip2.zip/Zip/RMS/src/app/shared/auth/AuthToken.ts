export class AuthToken{

    token_type:string;

    access_token:string;

    refresh_token:string;

    expires_in:string
}