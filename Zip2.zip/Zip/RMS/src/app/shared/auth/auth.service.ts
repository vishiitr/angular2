﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable, Subject } from 'rxjs';
import { JwtHelper } from 'angular2-jwt';
import { AuthToken } from './AuthToken';
// import {AppSettings} from' .. / .. Japp . settings';
import 'rxjs/add/operator/map';
//import { Permissions } from './Permissions';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class AuthService {
    readonly crntUserKey: string = "crntUser";
    readonly serviceBaseUrl: string = 'http://localhost:4200/';
    jwtHelper: JwtHelper;
    constructor(private http: HttpClient) {
        this.jwtHelper = new JwtHelper();
    }

    login(userId: string, password: string): Observable<boolean> {
        debugger;
        //let yy = Permissions.UserManagement.C;
        //let yy2 = Permissions.UserManagement.C.constructor.name;
        let token: AuthToken;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        let subject = new Subject<boolean>();

        this.http.post<AuthToken>("/api/authentication/Token", { userId: userId, password: password }, { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) })
            .subscribe((token) => {
                this.setUserToken(token);
                this.IsCurrentUserHasGivenPermission('PermissionA');
                subject.next(true);
                subject.complete();
            },
            response => {
                subject.next(false);
                subject.complete();
            },
            () => {
                console.log("The post observable is now completed");
            });
        return subject;

    }

    IsCurrentUserHasGivenPermission(permission: string): boolean {
        let hasPermission: boolean = false;
        let testResp: any = localStorage.getItem(this.crntUserKey);

        if (testResp != null) {
            let token: AuthToken = JSON.parse(localStorage.getItem(this.crntUserKey));
            if (token.access_token.length > 0
                && !this.jwtHelper.isTokenExpired(token.access_token)) {
                let decodedToken = this.jwtHelper.decodeToken(token.access_token);
                let decodedPermissions = <string[]>JSON.parse(decodedToken.Permissions);
                hasPermission = decodedPermissions.filter(item => item.toUpperCase() === permission.toUpperCase()).length > 0;
            }
        }

        return hasPermission;
    }

    IsCurrentUserAuthenticated(): boolean {
        let authenticationStatus: boolean = false;
        let testResp: any = localStorage.getItem(this.crntUserKey);

        if (testResp != null) {
            let token: AuthToken = JSON.parse(localStorage.getItem(this.crntUserKey));
            if (token.access_token.length > 0 && !this.jwtHelper.isTokenExpired(token.access_token)
            ) {
                authenticationStatus = true;
            }
        }
        return authenticationStatus;
    }


    logOut() {
        localStorage.removeItem(this.crntUserKey);
    }

    private setUserToken(token: AuthToken): boolean {
        localStorage.setItem(this.crntUserKey, JSON.stringify(token));
        return true;
    }

}