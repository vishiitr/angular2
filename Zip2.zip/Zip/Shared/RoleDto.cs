﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Shared
{
    public class RoleDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        //public BitArray Enabled { get; set; }
        public DateTime LastUpdate { get; set; }
        public Dictionary<string, List<FeaturePermissionDto>> FeaturePermissions { get; set; }
    }
}
