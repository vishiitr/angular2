﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shared
{
    public class RoleFeaturePermissionDto
    {
        public int RoleId { get; set; }
        public List<FeaturePermissionsDto> FeaturePermissions { get; set; }
    }

    public class FeaturePermissionsDto
    {
        public bool createPermissionName { get; set; }
        public bool deletePermissionName { get; set; }
        public bool readPermission { get; set; }
        public bool updatePermission { get; set; }
        public string featureName { get; set; }
    }
}
