﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Shared
{
    public class ReviewDto
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string TranslatedTitle { get; set; }
        public string TranslatedDesc { get; set; }
        public int StatusId { get; set; }
        public decimal? Rating { get; set; }
        public int? Type { get; set; }
        public DateTime? PostedDate { get; set; }
        public int? ChannelId { get; set; }
        public decimal? Score { get; set; }
        public int? LanguageId { get; set; }
        public int? PropertyId { get; set; }
        public string ReferenceNumber { get; set; }
        public long? CreatedBy { get; set; }
        public long? AssignedTo { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime DateCreated { get; set; }
        public long? ReservationId { get; set; }

        //public virtual ICollection<Problem> Problem { get; set; }
        //public virtual ICollection<ReviewComment> ReviewComment { get; set; }
        //public virtual ICollection<ReviewResponse> ReviewResponse { get; set; }
        //public virtual ICollection<ReviewTranslation> ReviewTranslation { get; set; }
        //public virtual Users AssignedToNavigation { get; set; }
        //public virtual Channel Channel { get; set; }
        //public virtual Language Language { get; set; }
        //public virtual Property Property { get; set; }
        //public virtual Reservation Reservation { get; set; }
        public ReviewStatusDto Status { get; set; }
        //public virtual ReviewType TypeNavigation { get; set; }
    }
}
