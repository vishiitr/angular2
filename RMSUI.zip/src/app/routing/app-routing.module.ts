﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router'
import { LoginComponent } from '../login/login.component'
import { LayoutComponent } from '../layout/layout.component';
import { AuthGuard } from '../shared/guards/auth.guard'
import { LoginGuard } from '../shared/guards/login.guard'
import { UserRoleComponent } from "../user/userRole.component";
import { DashboardComponent } from "../dashboard/dashboard.component";
import { UserComponent } from "../user/user.component";
import { DepartmentComponent } from "../user/department/department.component";
import { ReviewComponent } from "../review/review.component";


const routes: Routes = [
  { path: 'login', component: LoginComponent, canActivate: [LoginGuard] },
  {
    path: '', component: LayoutComponent, canActivate: [AuthGuard],
    children: [
      { path: 'role', component: UserRoleComponent },
      { path: 'user', component: UserComponent },
      { path: 'department', component: DepartmentComponent },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'review', component: ReviewComponent },
      { path: 'review/:tab', component: ReviewComponent },
      { path: 'review/:tab/:reviewId', component: ReviewComponent },
    ]
  },
  // { path: 'home', component: LayoutComponent, canActivate: [AuthGuard] },
  // { path: 'user', component: UserRoleComponent }
]

@NgModule({
  // imports: [
  //   CommonModule,
  //   RouterModule
  // ],
  // declarations: []
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
