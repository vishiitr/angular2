﻿import { Component, OnInit } from '@angular/core';
import { UserService } from "./user.service";
import { User } from "./user";
import { RoleService } from "./role.service";
import { DepartmentService } from "./department/department.service";

import { RMSNotifier } from "../shared/services/notifications/notifications.service";

declare let $: any;
@Component({
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
    public tableData1;
    public roles;
    public departments;
    public user = new User();

    constructor(private userService: UserService, private roleService: RoleService, private departmentService : DepartmentService) { }

    ngOnInit() {
        this.tableData1 = {
            headerRow: ['#', 'Name', 'Username', 'Email id', 'Actions'],
        };
        this.roleService.getRoles().subscribe(resp => this.roles = resp.Data);
        this.departmentService.getDepartments().subscribe(resp => this.departments = resp.Data);
        this.userService.getUsers().subscribe(resp => { this.tableData1.users = resp.Data; });
    }
    viewUser(id) {
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#myModal2').modal('show');

        this.userService.getUser(id).subscribe(resp => { this.user = resp.Data; console.log(this.user); });
    }
    save() {
        var self = this;
        console.log(this.user.Id)

        if (!this.user.Id) {
            this.user.Id = 0;
            this.user.Password = null;
            this.user.LastUpdate = "0001-01-01T00:00:00";
            this.userService.addUser(this.user).subscribe(res => {
                console.log(res)
                self.tableData1.users.push(res);
                $('#myModal2').modal('hide');
                RMSNotifier.success("User saved successfully!!");
            });
        }
        else {
            this.userService.editUser(this.user).subscribe(res => {
                self.tableData1.users.find((o, i) => {
                    if (o.Id === this.user.Id) {
                        self.tableData1.users[i] = this.user;                      
                        return true; // stop searching
                    }
                });
                $('#myModal2').modal('hide');
                RMSNotifier.success("User updated successfully!!");
            });
        }
    }

    deleteUser(id) {
        var self = this;
        this.userService.deleteUser(id).subscribe(res => {
            self.tableData1.users = self.tableData1.users.filter(obj => obj.Id !== id);
        }
        );
    }

    addUser() {
        $('.modal-dialog').width($('.main-content').width() + 30)
        $('#myModal2').modal('show');
        this.user = new User();
    }

    generateNotification() {
        RMSNotifier.warn("THIS IS WARNING testing from service");
        RMSNotifier.info("THIS IS INFO testing from service");        
    }
}
