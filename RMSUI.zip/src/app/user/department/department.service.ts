﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';


@Injectable()
export class DepartmentService {

    constructor(private http: Http) { }

    getDepartments() {
        return this.http.get('/api/Department/GetDepartments').map((response: Response) => response.json());
    }

    addDepartment(role: any) {
        return this.http.post('/api/Department/AddDepartment', role).map((response: Response) => response.json().Data);
    }

    editDepartment(role: any) {
        return this.http.put('/api/Department/EditDepartment', role).map((response: Response) => response.json().Data);
    }

    deleteDepartment(roleId: any) {
        return this.http.delete('/api/Department/DeleteDepartment?id=' + roleId).map((response: Response) => response.json().Data);
    }
}
