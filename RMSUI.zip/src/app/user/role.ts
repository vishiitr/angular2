﻿export class role {
    Id: number;
    Name: string;
    Description: string;
    FeaturePermissions: any;
    LastUpdate: "0001-01-01T00:00:00";    
}