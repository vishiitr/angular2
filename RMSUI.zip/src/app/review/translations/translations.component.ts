﻿import { Component, OnInit } from '@angular/core';
import { Review } from "../review";

@Component({
    selector: 'app-translations',
    templateUrl: './translations.component.html',
    styles: []
})
export class TranslationsComponent implements OnInit {
    public review = new Review();
    constructor() { }

    ngOnInit() {
    }

}
