﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { ReviewComponent } from './review.component';
import { ReservationComponent } from './reservation/reservation.component';
import { CommentsComponent } from './comments/comments.component';
import { TranslationsComponent } from './translations/translations.component';

@NgModule({
    imports: [RouterModule, FormsModule, CommonModule],
    declarations: [ReviewComponent, ReservationComponent, CommentsComponent, TranslationsComponent],
    exports: [ReviewComponent],
})
export class ReviewModule {

}
