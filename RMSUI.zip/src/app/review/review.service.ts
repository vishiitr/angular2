﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { myResponse } from '../shared/Response';
import { Review } from './review';

@Injectable()
export class ReviewService {
    constructor(private http: HttpClient) {
    }

    getReviews() {
        return this.http.get<myResponse<Review[]>>('/api/review/GetReviews');
    }

    getReview(id: number) {
        return this.http.get<myResponse<Review>>('/api/review/GetReview?id=' + id);
    }

    addReview(review: Review) {
        return this.http.post<myResponse<Review>>('/api/review/CreateReview', review);
    }

    editReview(review: Review) {
        return this.http.put('/api/review/EditReview?id=' + review.Id, review);
    }

    deleteReview(id: number) {
        return this.http.delete('/api/review/DeleteReview?id=' + id);
    }

    getReviewMetaData() {
        return this.http.get<myResponse<any>>('/api/review/GetReviewMetaData');
    }
}