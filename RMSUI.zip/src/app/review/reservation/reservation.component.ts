﻿import { Component, OnInit } from '@angular/core';
import { Review } from "../review";

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styles: []
})
export class ReservationComponent implements OnInit {
    public review = new Review();
  constructor() { }

  ngOnInit() {
  }

}
