﻿export class Review {
    Id: number;
    Title: string;    
    Description: string;
    TranslatedTitle: string;
    TranslatedDesc: string;
    Status: number;
    Rating: number;
    Type: number;
    PostedDate: Date;   
    ChannelId: number;
    Score: number;
    LanguageId: number;
    PropertyId: number;
    ReferenceNumber: string;
    CreatedBy: number;
    AssignedTo: number;
    LastUpdated: Date;
    DateCreated: Date;
    ReservationId: number;
}