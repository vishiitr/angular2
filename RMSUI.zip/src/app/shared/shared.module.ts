﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth/auth.service';
import { RouterModule } from '@angular/router'
import { AuthGuard } from './guards/auth.guard';
import { LoginGuard } from './guards/login.guard';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfigService } from './services/config/config.service';
import { RootContextService } from './services/config/root-context.service';
import { HttpWaitComponent } from './components/httpwait/httpwait.component'
import { AuthInterceptor } from './auth/authInterceptor';
import { MonitorInterceptor } from './services/interceptor/monitorinterceptor';
import { ifHasPermissionDirective } from './auth/ifHasPermission.directive';
import { disableifNotHavePermissionDirective } from './auth/disableifNotHavePermission.directive';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
    imports: [HttpClientModule, CommonModule, FormsModule,
        RouterModule],declarations: [HttpWaitComponent,
ifHasPermissionDirective,
        disableifNotHavePermissionDirective], exports: [HttpWaitComponent, ifHasPermissionDirective,
            disableifNotHavePermissionDirective],
    providers: [AuthService, AuthGuard, LoginGuard]
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                AuthService,
                AuthGuard,
                LoginGuard,
                ConfigService, RootContextService,
                {
                    provide: HTTP_INTERCEPTORS, useClass:
                    AuthInterceptor, multi: true
                },
                {
                    provide: HTTP_INTERCEPTORS, useClass:
                    MonitorInterceptor, multi: true
                }
            ]
        };
    }
}




