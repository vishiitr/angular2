﻿import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';
import { AuthService } from './auth.service';

@Directive({ selector: '[ifHasPermission]' })
export class ifHasPermissionDirective {
    @Input("ifHasPermission") permissionName: string;
    constructor(private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private authService: AuthService) {
    }

    ngOninit() {
        let hasPermission = this.authService.IsCurrentUserHasGivenPermission(this.permissionName);
        this.viewContainer.clear();
        debugger;
        if (hasPermission) {
            this.viewContainer.createEmbeddedView(this.templateRef);
        }
    }
}
