﻿import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { RootContextService } from '../services/config/root-context.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    constructor(private root: RootContextService) { }
    intercept(req: HttpRequest<any>, next: HttpHandler):
        Observable<HttpEvent<any>> {
        debugger;
        let heads;
        heads = {
            'Content-Type': 'application/json',
            'Authorization': '432423433'
        };
        const headers = new HttpHeaders(heads);
        const authReq = req.clone({
            headers: headers,
            reportProgress: false
        });

        return next.handle(authReq);
    }
}
