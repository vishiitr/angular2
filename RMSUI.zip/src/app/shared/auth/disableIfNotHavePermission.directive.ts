﻿import { Directive, ElementRef, Renderer, Input } from '@angular/core';
import { AuthService } from './auth.service';

@Directive({ selector: '[disablePermission]' })
export class disableifNotHavePermissionDirective {
    constructor(public el: ElementRef, public renderer:
        Renderer, public authService: AuthService) { }
    @Input("disablePermission") disablePermission: string;
    ngOninit() {
        let hasPermission =
            this.authService.IsCurrentUserHasGivenPermission(this.disablePermission);
        debugger;
        if (!hasPermission) {
            this.renderer.setElementAttribute(this.el.nativeElement, 'disabled', 'true ');
        }
        else {
            this.renderer.setElementAttribute(this.el.nativeElement,
                'disabled', null);
        }
    }
}