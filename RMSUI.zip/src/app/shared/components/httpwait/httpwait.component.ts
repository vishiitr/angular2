﻿import { Component, OnInit } from '@angular/core';
import { RootContextService } from '../../services/config/root-context.service';
@Component({
    selector: 'app-httpwait',
    templateUrl: './httpwait.component.html',
    styleUrls: ['./httpwait.component.css']
})
export class HttpWaitComponent implements OnInit {
    processing: boolean;
    constructor(private context: RootContextService) {
        debugger;
        this.processing = false;
    }

    ngOnInit() {
        debugger;
        this.context.maincontext.subscribe(
            res => {
                this.processing = res;
            });
    }
}