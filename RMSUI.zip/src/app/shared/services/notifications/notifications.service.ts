﻿
declare let $: any;

class NotificationService {
    
    success(message: string) {
        this.show('success', message);
    }
 
    error(message: string) {
        this.show('danger', message);
    }
 
    info(message: string) {
        this.show('info', message);
    }
 
    warn(message: string) {
        this.show('warning', message);
    }
 
    // TODO: Although not neccessary
    clear() {
        //this.show('success', message);;
    }

    private show(type, msg){
      $.notify({
        	icon: "notifications",
        	message: msg

        },{
            type: type,
            timer: 2000,
            placement: {
                from: 'bottom',
                align: 'right'
            }
        });
    }    
}

export const RMSNotifier = new NotificationService();