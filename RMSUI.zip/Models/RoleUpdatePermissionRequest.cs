﻿namespace RMS.Models
{
  public class RoleUpdatePermissionRequest
  {
    public string FeaturePermissionIds { get; set; }

    public int RoleId { get; set; }
  }
}