﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Collections.Generic;
using System;
using RMS.Models;
using Newtonsoft.Json;

namespace RMS.Controllers
{
    [Route("api/[controller]")]
    public class AuthenticationController : ApiController
  {
        private TokenOptions Options { get; }

        public AuthenticationController(IOptions<TokenOptions> options)
        {
            Options = options.Value;
        }

        [HttpPost("[action]")]
        public TokenResponse Token([FromBody]TokenRequest request)
        {
            // TODO: Authenticate request

            var token = new JwtSecurityToken(
                audience: Options.Audience,
                issuer: Options.Issuer,
                notBefore: DateTime.UtcNow,
                claims: new List<Claim>() {
                  new Claim("mysystemId", "temp" ),
                  new Claim("Name", "Amit Kumar"),
                  new Claim("Permissions", JsonConvert.SerializeObject(new string[] { "PermissionA","PermissionB" } )) },
                expires: Options.GetExpiration(),
                signingCredentials: Options.GetSigningCredentials());

            return new TokenResponse
            {
                token_type = Options.Type,                
                access_token = new JwtSecurityTokenHandler().WriteToken(token),
                refresh_token = Guid.NewGuid().ToString("N"),
                expires_in = (int)Options.ValidFor.TotalSeconds
            };
        }
    }
}
