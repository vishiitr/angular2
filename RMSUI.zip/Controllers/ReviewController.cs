﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Collections.Generic;
using System;
using RMS.Models;
using Business;
using Shared;
using System.Linq;

namespace RMS.Controllers
{
  [Route("api/[controller]/[action]")]
  public class ReviewController : Controller
  {
    IReviewFacade _reviewFacade;
    public ReviewController(IReviewFacade reviewFacade)
    {
      _reviewFacade = reviewFacade;
    }

    [HttpGet]
    public Result<IList<ReviewDto>> GetReviews()
    {
      return _reviewFacade.GetReviews();
    }

    [HttpGet]
    public Result<ReviewDto> GetReview(long id)
    {
      return _reviewFacade.GetReview(id);
    }

    [HttpPut]
    public bool EditReview([FromBody]ReviewDto review)
    {
      try
      {
        _reviewFacade.EditReview(review);
        return true;
      }
      catch(Exception ex)
      {
        return false;
      }
    }

    [HttpDelete]
    public bool DeleteReview(int id)
    {
      try
      {
        _reviewFacade.DeleteReview(id);
        return true;
      }
      catch
      {
        return false;
      }
    }

    [HttpPost]
    public Result<ReviewDto> CreateReview([FromBody]ReviewDto review)
    {
      return _reviewFacade.AddReview(review);
    }

    [HttpGet]
    public Result<ReviewMetaDataDto> GetReviewMetaData()
    {
      return _reviewFacade.GetReviewMetaData();
    }
  }
}
